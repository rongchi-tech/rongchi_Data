#### 安装

1，`centos8`网络设置

https://www.bilibili.com/video/BV1CP411T7PJ/?spm_id_from=333.337.search-card.all.click&vd_source=da0ca5a74459b110b3a6da903d245e14

```
nmcli c reload ens160
nmcli c up ens160
```

2，`centos8`建立源数据

https://blog.csdn.net/wykqh/article/details/123004620

3，`centos`切换`python`默认版本的最简单步骤（随手记）

https://blog.csdn.net/Tassel_YUE/article/details/140378167

4，`CentOS 8` 安装指定版本`ansible`

https://blog.csdn.net/weixin_40647946/article/details/134420842

5，安装`ansible`提示；`Error：Unable to find a match:ansible`解决方案；

https://blog.csdn.net/Lcongming/article/details/117867806

6，设置`linux`开机默认进入`root`用户

https://blog.csdn.net/qq_41930112/article/details/121761957#:~:text=%E4%BF%AE%E6%94%B9%E7%94%A8%E6%88%B7%E5%B1%9E%E6%80%A7%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6vi%20%2Fetc%2Fgdm%2Fcustom.conf%E8%AE%BE%E7%BD%AE%E8%87%AA%E5%8A%A8%E5%90%AF%E5%8A%A8%E3%80%90daemon%E3%80%91%E4%B8%8B%E6%96%B0%E5%A2%9E%E4%B8%A4%E8%A1%8C%EF%BC%8C%E8%AE%BE%E7%BD%AE%E8%87%AA%E5%8A%A8%E5%90%AF%E5%8A%A8%EF%BC%8C%E8%87%AA%E5%8A%A8%E5%90%AF%E5%8A%A8%E9%BB%98%E8%AE%A4%E4%B8%BATrue%EF%BC%8C%E7%94%A8%E6%88%B7%E4%B8%BAroot%23%20GDM,configuration%20storage%20%5Bdaemon%5DAutomaticLoginEnable%3DTrueAu_linux%E5%BC%80%E6%9C%BA%E9%BB%98%E8%AE%A4%E7%94%A8%E6%88%B7

#### 主机清单

执行`ansible`的主机一般称为主控端

`Ansible`的主要功能在于批量主机操作

- `/etc/ansible/ansible.cfg`主配置文件，配置`ansible`工作特性
- `/etc/ansible/roles/`存放角色的目录

```bash
# 创建主机清单配置文件
vim /etc/ansible/hosts

# 添加不同的主机清单
[websrvs]
192.168.245.135		192.168.88.101
192.168.245.176		192.168.88.102

[dbsrvs]
192.168.245.176		192.168.88.101
192.168.245.135		192.168.88.102

[appsrvs]
192.168.245.[134:135]	192.168.88.[101:103]

# 查看管理的主机
ansible all --list-host
```

![image-20240809105746129](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809105746129.png)

启动命令

```bash
`基于key验证 执行ping命令`
# 先生成主控端的钥匙对
ssh-keygen
# 复制到被控制端主机
ssh-copy-id 192.168.245.135
ssh-copy-id 192.168.245.176
ssh-copy-id 192.168.245.134
# 执行
ansible all -m ping

`基于密码验证 执行ping命令`
# 首先获取root权限
su -
# 执行
ansible all -k -m ping
```



#### 1.`absible`工具

##### `ansible-doc`

此工具存放各种模块的帮助

格式：

```bash
ansible-doc [options] [module...]
-l --list  #列出可用模块
-s --snippet  #显示指定模块的playbook片段
```

范例：

```bash
# 列出所有模块
ansible-doc -l
# 查看指定模块帮助用法
ansible-doc -s shell
```

##### `ansible`

此工具通过ssh协议(基于用户名密码或者基于key验证)，实现对远程主机的配置管理，应用部署，任务执行等功能

格式：

```bash
ansible <host-pattern> [-m module_name] [-a args]
ansible	 主机清单主机		-m	模块名		   -a '路径'
```

选项说明：

```bash
--version		# 显示版本
-m module		# 指定模块，默认为command
-v				# 详细过程 -vv -vvv更详细
--list-hosts	# 显示主机列表，可简写 --list
-k,--ask-pass   # 提示输入ssh连接密码，基于密码验证(默认key验证)
-C,--check		# 检查，并不执行
-T,--timeout=TIMEOUT	# 执行命令的超时时间，默认10s
-u,--user=REMOTE_USER	# 执行远程执行的用户
-b,--become		# 代替旧版的sudo 切换
--become-user=USERNAME	# 指定sudo的runas用户，默认为root
-K,--ask-become-pass	# 提示输入sudo时的口令
```

显示主机列表，可简写 --list

![image-20240809142603213](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809142603213.png)

**通配符 *号**

`all`和*号是等价的

```bash
ansible "*" -m ping 
ansible 192.168.1.* -m ping
```

**逻辑或**

```bash
# 在websrvs组或者在dbsrvs组中的主机
ansible "websrvs:dbsrvs" -m ping
ansible "192.168.1.10:192.168.2.10" -m ping
```

**逻辑与**

```bash
# 在websrvs组并且在dbsrvs组中的主机
ansible "websrvs:&dbsrvs" -m ping
```

**逻辑非**

```bash
# 在websrvs组，但不在dbsrvs组中的主机
#注意：逻辑非只能单引号
ansible 'websrvs:!dbsrvs' -m ping
```

**正则表达式**

```bash
# 查询以web开头或者db开头的主机
ansible "~(web|db)srvs" -m ping
```

![image-20240809145438513](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809145438513.png)

**`ansiblle`命令执行过程**

- 加载自己的配置文件 默认`/etc/ansible/ansible.cfg`
- 加载自己对应的模块文件，如:`command`
- 通过`ansible`将模块或命令生成对应的临时`py`文件，并将该文件传输至远程服务器的对应执行用户`$HOME/.ansible/tmp/ansible-tmp-数字/XXX.PY`文件
- 给文件+x执行

* 执行并返回结果
* 删除临时`py`文件，退出

**`ansible`使用范例**

```bash
# 以wang用户执行ping存货检测
ansible all -m ping -u wang -k
# 以wang sudo至root执行ping存货检测
ansible all -m ping -u wang -k -b
```

##### `ansible-galaxy`

此工具会连接 https://galaxy.ansible.com下载相应的roles

##### `ansible-pull`

此工具会推送`ansible`的命令至远程，效率无限提升，对运维要求较高

##### `ansible-playbook`

此工具用于执行编写好的`playbook`任务

范例:

```bash
ansible-playbook hello.yml
cat hello.yml
---
# hello world yml file
- hosts: websrvs
  remote_user: root
  tasks:
    - name: hello world
      command: /usr/bin/wall hello world
```

![image-20240809165925156](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809165925156.png)

##### `ansible-vault`

此工具可以用于**加密解密yml文件**

格式：

```bash
ansible-vault [create|decrypt|edit|encrypt|rekey|view]
```

范例：

```bash
ansible-vault encrypt hello.yml  #加密
ansible-vault decrypt hello.yml  #解密
ansible-vault view hello.yml  #查看
ansible-vault edit hello.yml  #编辑加密文件
ansible-vault rekey hello.yml  #修改口令
ansible-vault create hello.yml  #创建新文件
```

1，文件加密

![image-20240809170758097](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809170758097.png)

被加密的文件无法直接执行

![image-20240809171053980](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809171053980.png)

2，文件解密

![image-20240809171249396](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240809171249396.png)

##### `ansible-console`

此工具可交互执行命令(**交互式命令**)，支持`tab,ansible 2.0+`新增

提示符格式：

```bash
执行用户@当前操作的主机组 (当前组的主机数量)[f:并发数]$
```

常用子命令：

- 设置并发数：`forks n` 列如：`forks 10`
- 切换组： `cd`主机组 列如：`cd web`
- 列出当前组主机列表：`list`
- 列出所有的内置命令：？或`help`

范例：

```bash
root@a11(2)[f:5]$ list		# 列出当前主机
root@a11(2)[f:5]$ cd appsrvs	# 切换主机
root@appsrvs(2)[f:5]$ list
root@appsrvs(2)[f:5]$ yum name=httpd state=present
root@appsrvs(2)[f:5]$ service name=httpd state=started
```

#### 2.`ansible`模块

##### command模块

功能：在远程主机执行命令，此为默认模块，可忽略`-m`选项

注意：此命令不支持`$VARNAME< > | ; &`等，用`shell`模块实现

范例：

```bash
ansible all -m command -a 'Linux命令'
```

##### shell模块

功能：和`command`相似，用`shell`执行命令，支持特殊符号

范例：

```bash
ansible all -m shell -a 'Linux命令'
```

修改主机名`hostname 主机名`

查看主机名`echo $HOSTNAME`

![image-20240812092711550](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240812092711550.png)

案例：查看系统当前时间

![image-20240813105839937](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240813105839937.png)



##### script模块

功能：将`ansible`服务器上的脚本在远程主机上运行

范例：

```bash
ansible websrvs -m script -a '/data/test.sh'
```

![image-20240813142626157](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240813142626157.png)



##### copy模块

功能：从`ansible`主控端复制文件到远程主机

```bash
# 如果目标存在，默认覆盖
ansible all -m copy -a 'src=指定要复制的本地文件或目录的路径 dest= src的内容会被复制到这里'
```

主要参数：

```bash
src
描述：指定要复制的本地文件或目录的路径
dest
描述：指定目标主机上文件或目录的路径。src 的内容会被复制到这里
owner
描述：指定目标文件的所有者
group
描述：指定目标文件的组
mode
描述：指定目标文件的权限模式（八进制）
backup
描述：如果目标文件已经存在，是否在覆盖前备份旧文件。默认覆盖，默认值为 yes
示例：backup=yes
force
描述：如果目标文件已经存在并且内容不同，是否强制覆盖文件。默认值为 yes
示例：force=no
content
描述：直接在 copy 模块中提供文件内容，而不是通过 src 指定文件
示例：content="test line1"
validate
描述：在复制前对文件进行验证，比如可以用来检查配置文件语法是否正确
```

案例：

1，使用`copy`参数中`content`参数，在`[websrvs]`主机清单中生成`test line`和`test line2`两行内容，写入`/tmp`下`test.txt`文件

```bash
ansible websrvs -m copy -a 'content="test line1\ntest line2" dest=/tmp/test.txt'
```

![image-20240813150745876](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240813150745876.png)

2，查看生成的内容

![image-20240813150942838](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240813150942838.png)

##### fetch模块

功能：从远程主机提取文件至`ansible`的主控端，与`copy`相反

范例：

```bash
ansible all -m fetch -a 'src= 远程主机上要获取的文件路径 dest= 保存到控制节点上的本地路径'
```

主要参数：

```bash
- `src`：必需参数，指定从远程主机上要获取的文件路径
- `dest`：必需参数，指定将文件保存到控制节点上的本地路径。如果指定的路径是目录，文件会保存到该目录下，保持与原路径相同的结构
- `flat`：可选参数，默认为 `no`。如果设置为` yes`，则会将文件保存到 `dest` 目录中，而不保留源文件的目录结构
- `fail_on_missing`：可选参数，默认为 `yes`。如果设置为 `no`，当源文件不存在时任务不会失败
- `validate_checksum`：可选参数，默认为 yes。下载文件时验证校验和，以确保文件的一致性。如果设置为 no，则不进行校验和验证
- `backup`：可选参数，默认为 `no`。如果设置为 `yes`，并且目标文件已经存在，那么在覆盖文件之前会生成一个备份
```

案例：

1，把其他主机的信息，各自生成到`ansible`服务器的`/data/os`目录下，并且生成各自的子目录

```bash
ansible all -m fetch -a 'src=/etc/redhat-release dest=/data/os'
```

![image-20240814092512025](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814092512025.png)

2，查看生成内容

![image-20240814093010054](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814093010054.png)



##### file模块

功能：设置文件属性

```bash
ansible all -m file -a 'path=要管理的文件或目录的路径'
```

主要参数：

```bash
path: （必需）指定要管理的文件或目录的路径
state: 指定文件的状态，可以是以下之一：
        absent：如果存在，删除文件或目录
        directory：确保路径为目录，如果不存在则创建
        file：确保路径为普通文件（如果目录或符号链接存在，则会被删除）
        link：确保路径为符号链接，并通过 src 参数指定链接目标
        touch：如果文件不存在，则创建一个空文件
owner: 指定文件的所有者
group: 指定文件的所属组
mode: 指定文件权限，格式可以是四位数字（如 0644）
src: 当 state=link 时，指定符号链接的目标路径
recurse: 递归地应用权限或所有权，常用于目录（值为 yes 或 no）
```

案例：

```bash
# 创建空文件
ansible all -m file -a 'path=/data/test.txt state=touch'
# 删除文件
ansible all -m file -a 'path=/data/test.txt state=absent'

# 把/test.txt文件所属用户改成wang，执行权限改为755
ansible all -m file -a 'path=/data/test.txt owner=wang mode=755'
# 创建目录
ansible all -m file -a 'path=/data/mysql state=directory'
```



##### `unarchive`模块

功能：解包解压缩

两种实现方法：

1，将`ansible`主机上的压缩包传到远程主机后**解压缩**至特定目录，设置`copy=yes`

2，将远程主机上的某个压缩包解压缩在指定路径下，设置`copy=no`

范例：

```bash
ansible all -m unarchive -a "src=<源路径> dest=<目标路径> [extra_opts=<额外解压选项>] [remote_src=<是否使用远程文件>] [copy=<是否复制到远程主机>]"

ansible all -m unarchive -a 'src=<源路径> dest=<目标路径>'
```

主要参数：

- `copy`: 默认为`yes`，当`copy=yes`，拷贝的文件是从`ansible`主机复制到远程主机上，如果设置为`copy=no`，会在远程主机上寻找`src`源文件
- `remote_src`: 和`copy`功能一样且互斥，`yes`表示在远程主机，不在`ansible`主机，`no`表示文件在`ansible`主机上
- `src`: 源路径，可以是`ansible`主机上的路径，也可以是远程主机上的路径，如果是远程主机上的路径，则需要设置`copy=no`
- `dest`: 远程主机上的目标路径
- `mode`: 设置解压缩后的文件权限

案例：

1，压缩目录`/etc`，放在`/data`下，压缩文件名称为`etc.tar.gz`

```bash
tar zcvf /data/etc.tar.gz /etc
```

2，将`ansible`主控端`/data`文件夹下的`etc.tar.gz`包解压缩在[websrvs]主机清单`/data`下

```bash
ansible websrvs -m unarchive -a 'src=/data/etc.tar.gz dest=/data/'
```

![image-20240814102206535](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814102206535.png)

3，查看发现存在`/etc`目录，代表执行成功

- 这里`copy=yes`，就是：将`ansible`主机的压缩包传到远程主机后**解压缩**至特定目录
- 因为压缩目录是`/etc`，最后解压缩也是目录`/etc`

```bash
# 查看websrvs主机清单 /data下所有文件及文件夹
ansible websrvs -m shell -a 'more /data/*'
```

![image-20240814102418502](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814102418502.png)

##### archive模块

功能：打包压缩

范例：

```bash
ansible all -m archive -a "path=<源路径> dest=<目标路径> [format=<归档格式>] [remove=<是否删除源文件>]"

ansible all -m archive -a 'path=<源路径> dest=<目标路径>'
```

主要参数:

- `path`或`src`：指定要归档的源文件或目录的路径。可以是文件或目录的路径
- `dest`：指定生成的归档文件的目标路径和名称。通常以 `.tar.gz` 或` .zip` 作为后缀
- `format`（可选）：指定归档的格式。支持的格式包括` tar、zip` 等。默认格式是 `gzipped tarball`，即 `.tar.gz` 格式
- `remove`（可选）：是否在归档后删除源文件或目录。可以设置为 `yes` 或 `no`，默认值是 `no`

案例：

1，将`ansible`主控端`/var/log/`下的所有文件，打包压缩至`[websrvs]`主机清单`=/data`下，名称为`log.tar.bz2`，打包格式为`bz2`

```bash
ansible websrvs -m archive -a 'path=/var/log/ dest=/data/log.tar.bz2 format=bz2'
```

![image-20240814113222704](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814113222704.png)

2，查看内容

```bash
ansible websrvs -m shell -a 'ls /data/'
```

![image-20240814113310925](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814113310925.png)



##### hostname模块

功能：管理主机名

范例：

```bash
# 更改一个主机名
ansible [特定主机ip] -m hostname -a 'name= 主机名'
```

更改192.168.245.135的主机名

```bash
ansible 192.168.245.135 -m hostname -a 'name=ansible'
```



##### `cron`模块

功能：计划任务

支持时间：`minute,hour,day,month,weekday`

范例：

```bash
# 创建计划任务
# 每周一至周五运行2小时30分钟，计划任务名为backup mysql
ansible dbsrvs -m cron -a 'hour=2 minute=30 weekday=1-5 name="backup mysql" job=/root/mysql_backup.sh'

# 查看任务
ansible dbsrvs -m shell -a 'crontab -l'
# 或者直接去看文件
ansible dbsrvs -a 'cat /var/spool/cron/root'

# 禁用计划任务
ansible dbsrvs -m cron -a 'hour=2 minute=30 weekday=1-5 name="backup mysql" job=/root/mysql_backup.sh disabled=yes'
# 启用计划任务
ansible dbsrvs -m cron -a 'hour=2 minute=30 weekday=1-5 name="backup mysql" job=/root/mysql_backup.sh disabled=no'

# 删除计划任务
ansible dbsrvs -m cron -a 'name="backup mysql" state=absent'
```

常见参数：

```bash
name: 定时任务的描述或名称。用于标识任务
minute: 指定任务运行的分钟，范围为 0-59 或者 * 表示每分钟
hour: 指定任务运行的小时，范围为 0-23 或者 * 表示每小时
day: 指定任务运行的天数，范围为 1-31 或者 * 表示每一天
month: 指定任务运行的月份，范围为 1-12 或者 * 表示每个月
weekday: 指定任务运行的星期几，范围为 0-6 (0 代表星期天) 或者 * 表示每周的每一天
job: 实际要执行的脚本命令
state: 可以是 present（创建或更新任务）或 absent（删除任务）

disabled: 在创建任务语句后面加上disabled=yes(禁用计划任务)，disabled=no(启用计划任务)
```

案例：

1，在主机清单`[dbsrvs]`中，创建名为`backup mysql`的计划任务，每周1~5日运行2小时30分钟

```bash
ansible dbsrvs -m cron -a 'hour=2 minute=30 weekday=1-5 name="backup mysql" job=/root/mysql_backup.sh'
```

![image-20240814150657911](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814150657911.png)

2，查看任务

```bash
ansible dbsrvs -m shell -a 'crontab -l'
```

![image-20240814150547882](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814150547882.png)

3，禁用任务并查看

![image-20240814151101245](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814151101245.png)

4，启动任务并查看

![image-20240814151331214](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814151331214.png)

5，删除任务并查看

```bash
ansible dbsrvs -m cron -a 'name="backup mysql" state=absent'
```

![image-20240814151604481](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814151604481.png)



##### yum模块

功能：管理软件包

范例：

```bash
ansible all -m yum -a 'name=httpd state=present' # 安装
ansible all -m yum -a 'name=httpd state=absent'	 # 卸载
```

常用参数：

```bash
name: 指定要安装、更新或删除的软件包名称。可以指定单个包名、逗号分隔的多个包名，或使用通配符
state: 指定软件包的状态，可以是以下值：
        present: 安装软件包，如果已经安装，则不做任何操作
        absent: 删除软件包
        latest: 更新软件包到最新版本
        reinstalled: 重新安装软件包
```



##### service模块

功能：管理服务

```bash
# 查看已启动服务端口号
ansible all -m shell -a 'ss -ntl'
```

常用参数：

```bash
name: 指定要管理的服务名称（必须提供）
state: 定义服务的期望状态，可以是以下之一：
        started: 启动服务（如果尚未运行）
        stopped: 停止服务（如果正在运行）
        restarted: 重启服务
        reloaded: 重新加载服务的配置（如果支持此操作）
enabled: 设置为 yes 或 no，表示服务是否应在开机时自动启动。
sleep: 在尝试操作之前等待的时间（秒）
pattern: 使用此参数来匹配运行的服务进程，帮助识别服务是否正在运行（对于某些系统有用）
use: 用于指定使用哪个后台服务管理工具，常见的有 sysvinit, upstart, systemd 等，默认是自动检测
```

范例：

```bash
# 启动httpd服务
ansible all -m service -a "name=httpd state=started"

# 查看端口,显示80代表启动成功
ansible all -m shell -a 'ss -ntl's

# 停止服务
ansible all -m service -a "name=httpd state=stopped"
```

![image-20240814162749945](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814162749945.png)

```bash
# 开机自启动
ansible all -m service -a "name=httpd state=started enabled=yes"
```



##### group模块

功能：管理组

范例：

```bash
# 创建组
ansible websrvs -m group -a 'name=nginx gid=88 system=yes'
# 删除组
ansible websrvs -m group -a 'name=nginx system=yes'
```

常用参数：

```bash
name: 指定要管理的组名（这是必需的）
gid: 指定组的 GID（组标识符）。如果不指定，系统会自动分配一个
state: 指定组的状态，可以是以下值：
        present: 确保该组存在。如果组不存在，则会创建它
        absent: 确保该组不存在。如果组存在，则会删除它
system: 如果设置为 yes，表示该组是一个系统组（系统组的 GID 通常低于 1000）
local: 如果设置为 yes，在没有网络时，组只会在本地创建（适用于某些系统）
```

案例：

1，创建一个系统组，指定组标识符为88，组名为`nginx`

```bash
ansible websrvs -m group -a 'name=nginx gid=88 system=yes'
```

![image-20240814164431536](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814164431536.png)

2，删除组

```bash
ansible websrvs -m group -a 'name=nginx system=yes'
```

![image-20240814164622150](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240814164622150.png)

##### user模块

功能：管理用户

常见参数：

```bash
name: 指定要管理的用户名（这是必需的）
uid: 为用户指定一个用户标识符（UID）
group: 为用户指定一个主要组
groups: 为用户指定附加的组，可以是逗号分隔的列表
state: 指定用户的状态，可以是以下值：
        present: 确保用户存在。如果用户不存在，则会创建它
        absent: 确保用户不存在。如果用户存在，则会删除它
password: 为用户设置加密后的密码。可以通过 mkpasswd 工具生成加密的密码
shell: 指定用户的登录 shell
home: 指定用户的主目录路径
createhome: 如果设置为 yes，在创建用户时自动创建主目录
comment: 为用户提供描述信息（通常是用户的全名）
system: 如果设置为 yes，表示该用户是系统用户（系统用户的 UID 通常低于 1000）
remove: 如果设置为 yes，在删除用户时一并删除用户的主目录及邮件文件
```

范例：

创建用户：

- 创建一个用户，名字是`nginx`，全名是`nginx`,用户标识符是88，所属组为`nginx`，所属附加组为`root,daemon`
- 在`[websrvs]`主机清单中，用户`nginx`设置登录的`shell`是`/sbin/nologin`
- `nginx`是系统用户，`create_home=no`表示不创建家目录，家目录路径在`/data/nginx`
- `non_unique=yes`表示用户`UID`可以重复

```bash
ansible websrvs -m user -a 'name=nginx comment=nginx uid=88 group=nginx groups="root,daemon" shell=/sbin/nologin system=yes create_home=no home=/data/nginx non_unique=yes'
```

删除用户及家目录等数据：

- 删除名为`nginx`用户
- 确保用户不存在，存在就会删除
- 删除用户，主目录及邮件文件

```bash
ansible websrvs -m user -a 'name=nginx state=absent remove=yes'
```



##### lineinfile模块

功能：修改文件内容，模块用于在文件中添加、删除或替换特定的行

范例：

```bash
# 把路径为/etc/selinux/config文件下，以"^SELINUX="开头的文件，替换为"SELINUX=enforcing"
ansible all -m linefile -a 'path=/etc/selinux/config regexp="^SELINUX=" line="SELINUX=enforcing"'

`不写line="SELINUX=enforcing"这行，表示删除以"^SELINUX="开头的文件`
ansible all -m linefile -a 'path=/etc/selinux/config regexp="^SELINUX="'
```

常见参数：

```bash
path 或 dest (必需):
    目标文件的路径
    示例: path=/etc/ssh/sshd_config
line:
    要插入或替换的行内容
    示例: line='PermitRootLogin no'
state:
    指定行的状态，可以是 present (默认) 或 absent
    present: 确保行存在于文件中
    absent: 确保行不存在于文件中
    示例: state=present
regexp:
    正则表达式，用于匹配要替换的行。如果匹配到，则会替换匹配到的行
    示例: regexp='^PermitRootLogin'
insertafter:
    指定新行插入的位置，可以是 EOF（文件末尾）或者是一个匹配的正则表达式
    示例: insertafter='^#PermitRootLogin'
insertbefore:
    与 insertafter 类似，但指定新行插入在匹配行的前面
    示例: insertbefore='^#PermitRootLogin'
backrefs:
    当 regexp 参数和 line 参数一起使用时，设置为 yes 可以使用正则表达式组捕获和替换
    示例: backrefs=yes
backup:
    设置为 yes 时，在修改文件前会备份原文件
    示例: backup=yes
```

案例：

1，在`/etc/fstab`目录下，把`fstab`文件中，以`#`号开头的行删除，`state=absent`却保以`#`号开头的行不在文件中

```bash
ansible all -m linefile -a 'dest=/etc/fstab state=absent regexp="^#"'
```

![image-20240815094015024](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815094015024.png)

2，查看内容已无`#`号开头行

![image-20240815100943084](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815100943084.png)

##### replace模块

该模块有点类似与`sed`命令，主要也是基于正则进行 匹配和替换

```bash
# 在/etc/fstab文件路径中，把UUID开头的行替换为#开头
ansible all -m replace 'path=/etc/fstab regexp="^(UUID.*)" replace="#\1"'
# 对上面这条指令的替换反转
ansible all -m replace 'path=/etc/fstab regexp="^#(.*)" replace="\1"'
```

常用参数：

```bash
path: 必须指定，表示文件路径
regexp: 必须指定，表示需要匹配的正则表达式
replace: 必须指定，表示要替换成的文本内容
backup: （可选）设置为 yes 时，会在修改前创建文件备份。备份文件将以 .bak 结尾
before: （可选）用于匹配替换操作前面的文本，帮助定位需要替换的区域
after: （可选）用于匹配替换操作后面的文本，帮助定位需要替换的区域
validate: （可选）在修改文件之前执行指定的命令验证文件，命令中 %s 会被替换为文件名
```



##### setup模块

功能：`setup` 模块来收集主机的系统信息，这些 `facts` 信息可以直接以变量的形式使用，但是如果主机较多，会影响执行速度，可以使用 `gather_facts:no` 来禁止 `Ansible` 收集 `facts` 信息

范例：

```bash
ansible 192.168.245.135 -m setup
gather_facts: no
```



#### `Playbook`

![image-20240815105936009](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815105936009.png)

`playbook` 剧本是由一个或多个“play"组成的列表

`Playbook` 文件是采用`YAML`语言编写的

`play`的主要功能在于将预定义的一组主机，装扮成事先通过`ansible`中的`task`定义好的角色。Task实际是调用`ansible`的一个`module`，将多个`play`组织在一个`playbook`中，即可以让它们联合起来，按事先编排的机制执行预定义的动作

#### `YAML`语言

`YAML`官方网站：http://www.yaml.org

`YAML`特点:

```yaml
YAML的可读性好
YAML和脚本语言的交互性好
YAML使用实现语言的数据类型
YAML有个一致的信息模型
YAML易于实现
YAML可以基于流来处理
YAML表达能力强，扩展性好
```

`YAML`语法简介:

- 在单一文件第一行，用连续三个 `---`开始
- 第二行一般是`playbook`的内容说明
- 使用`#`号注释代码

- 缩进必须统一
- `key-value`的值均需要大小写敏感，多个`key-value`可以同行写，可以换行
- `value`可以是字符串，列表
- 一个完整代码块功能最少包括`name`和`task`
- 一个`name`只能包括一个`task`
- `YAML`文件扩展名统称为`yml`或`yaml`

##### List列表

列表由多个元素组成，且所有元素前均使用`-`

```bash
# A list of tasty fruits
- Apple
- Orange
- Strawberry
- Mango

[Apple Orange Strawberry Mango]
```

##### Dictionary字典

字典通常由多个`key`与`value`构成

注意：`键: 值`，`key:`后面一定要有空格在跟上值

```bash
# An employee record
name: Example Deverloper
job: Developer
shill: Elite

也可以将key: value放置于{}中进行表示,用`,`号分隔多个key：value
{name: "Example Developer",job: "Developer",skill: "Elite"}
```

范例：

```bash
YAML的语法和其他高阶语言类似，并且可以简单表达清单、散列表、标量等数据结构。
其结构（Structure）通过空格来展示，序列（Sequence）里的项用"-"来代表，Map里的键值对用":"分隔
示例
    name: John Smith
    age: 41
    gender: Male
    spouse:
      name: Jane Smith
      age: 37
      gender: Female
    children:
      - name: Jimmy Smith
        age: 17
        gender: Male
      - name: Jenny Smith
        age: 13
        gender: Female
```

![image-20240815150013524](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815150013524.png)

##### 三种常见数据格式及转换:

- `XML:Extensible Markup Language`，可扩展标记语言，可用于数据交换和配置
- `JSON:JavaScript Object Notation,JavaScript` 对象表记法，**主要用来数据交换**或配置，不支持注释
- `YAML: YAML Ain't Markup Language YAML`不是一种标记语言，**主要用来配置**，大小写敏感，不支持`tab`

![image-20240815144630363](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815144630363.png)

**互相转换工具网站**

https://www.json2yaml.com/

#### 3.`Playbook`核心元素

- `Hosts` 执行的远程主机列表 (指定应用在那些主机上)
- `Tasks` 任务集 (调用各种`ansible`模块)
- `Variables` 内置变量或自定义变量在`playbook`中调用
- `Templates` 模板，可替换模板文件中的变量并实现一些简单逻辑的文件
- `Handlers` 和 `notify`结合使用，由特定条件触发的操作，满足条件方才执行，否则不执行
- `tags` 标签 指定某条任务执行，用于选择运行`playbook`中的部分代码。`ansible`具有幕等性，因此会自动跳过没有变化的部分，即便如此，有些代码为测试其确实没有发生变化的时间依然会非常地长。此时，如果确信其没有变化，就可以通过`tags`跳过此些代码片断

##### hosts组件

`Hosts:plavbook`中的每一个`play`的目的都是为了让特定主机以某个指定的用户身份执行任务。`hosts`用于指定要执行指定任务的主机，须事先定义在主机清单中

```bash
websrvs:dbsrvs		# 或者，在websrvs或者在dbsrvs
websrvs:&dbsrvs		# 与，既在websrvs又在dbsrvs
websrvs:!dbsrvs		# 在websrvs组，但不在dbsrvs组
```

案例:

```bash
- hosts: websrvs:dbsrvs
```

##### remote_user组件

`remote_user`: 可用于`Host`和`task`中。也可以通过指定其通过`sudo`的方式在远程主机上执行任务，其可用于play全局或某任务;此外，甚至可以在`sudo`时使用`sudouser`指定`sudo`时切换的用户

不写`remote_user`默认远程连接在`root`上

```yaml
- hosts: websrvs
  remote_user: root
  
  tasks:
    - name: test connection
      ping:
      remote_user: magedu
      sudo: yes				# 默认sudo为root
      sudo_user:wang		# sudo为wang
```

##### task列表

`play`的主体部分是`task list`，`task list`中有一个或多个`task`，各个`task`按次序逐个在`hosts`中指定的主机上执行

`task`格式：

```yaml
module: arguments
模块: 参数
# shell和command模块后面跟linux命令，而非key=value
```

`playbook`范例：

```yaml
---
- hosts: websrvs
  remote_user: root
  tasks:
    - name: install httpd
      yum: name=httpd	#通过yum模块安装httpd
    - name: start httpd
      service: name=httpd state=started enabled=yes	 #通过service模块使httpd启动，并且开机自启动
```

![image-20240815155526783](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815155526783.png)

#### 4.`playbook`命令

https://galaxy.ansible.com/

格式：

```bash
ansible-playbook <filename.yml> ... [options]
```

常见选项

```bash
-C --check		#只检测可能会发生改变，但不真正执行操作
--list-hosts	#列出运行任务的主机
--list-tags		#列出tag
--list-tasks	#列出task
--limit	主机列表  #只针对主机列表中的主机执行
-v -vv -vvv		#显示过程
```

##### 利用`playbook`安装`mysql`用户

范例： `create_mysql.yml`

```yaml
---
- hosts: dbsrvs			# 指定主机清单为[dbsrvs]
  remote_user: root		# 连接在root上
  gather_facts: no		# `gather_facts:no` 来禁止 `Ansible` 收集 `facts` 主机信息（来自于setup模块）

  tasks:
    - name: create group					# name的描述文字是create group
      group: name=mysql system=yes gid=306	# 调用group模块，组名mysql，是系统组，组ID=306
    - name: create user
      user: name=mysql system=yes group=mysql uid=306 home=/data/mysql create_home=no
      # 掉用user模块,创建了用户叫mysql，是系统用户，属于mysql组，uid=306，主目录路径/data/mysql
```

1，编辑脚本`/data/ansible/create_mysql.yml`添加上面`.yml`代码

2，测试代码

```yaml
ansible-playbook -C create_mysql.yml 
```

![image-20240815172229430](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815172229430.png)

3，执行`create_mysql.yml `脚本，此时在[dbsrvs]主机清单包含的IP地址机器上执行`.yml`

```yaml
ansible-playbook  create_mysql.yml
```

![image-20240815172345698](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815172345698.png)

4，查看脚本

```yaml
ansible dbsrvs -a 'getent passwd mysql'
-或
ansible dbsrvs -a 'id mysql'
```

![image-20240815172511148](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240815172511148.png)



##### `handlers`和`notify`

触发条件：主要用于当关注的资源发生变化时，才会采取一定的操作。在`notify`中列出的操作称为`handler`

也即`notify`中调用`handler`中定义的操作。`handlers`可以有多个任务，`notify`可以触发多个

```
handlers
handlers 是一组特殊的任务，这些任务只有在被通知（即通过 notify）时才会被执行。典型的用例是需要在系统状态发生变化时执行一些后续操作，例如重启服务、重新加载配置等。

handlers 通常定义在 playbook 或 role 中，并且是由 notify 触发的。一个 handler 是一个任务，因此可以使用和普通任务一样的 Ansible 语法。

notify
notify 是用于通知 handlers 的指令。notify 通常放在任务定义中，当该任务执行并发生变化时，会触发相应的 handler。
```

范例：

```yaml
---
- hosts: websrvs
  remote_user: root

  tasks:
    - name: install nginx
      yum: name=nginx
    - name: template config to remote hosts
      template: src=nginx.conf.j2 dest=/etc/nginx/nginx.conf
      notify: restart nginx		#restart nginx这是handler要操作的对象
    - name: start service
      service: name=nginx state=started enabled=yes

  handlers:						
    - name: restart nginx		#notify要调用的操作	
      service: name=nginx state=restarted
```

![image-20240826114647902](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826114647902.png)



##### `Playbook`中使用`tags`

在`Playbook`文件中，可以利用`tags`组件，为特定`task`指定标签，当在执行`playbook`时，可以只执行特定`tags`的`task`，而非整个`playbook`文件

```yaml
vim httpd.yml
---
# 标签范例
- hosts: websrvs
  remote_user: root
  gather_facts: no
  
  tasks:
    - name: install httpd
      yum: name=httpd state=present
    - name: install configure file
      copy: src=files/httpd.conf dest=/etc/httpd/conf/
      tags: conf		# 标签
    - name: start httpd service
      tags: service		# 标签
      service: name=httpd state=started enabled=yes
      
# 执行 conf和service这两个标签，没有标签的yum就不会执行
ansible-playbook -t conf,service httpd.yml
```



#### 5.`playbook`中变量使用

变量名：仅能由字母，数字和下划线组成，**且只能以字母开头**

**变量定义：**

```
variable=value
```

范例：

```yaml
http_port=80
```

**变量调用方式：**

通过`{{ variable_name }}`调用变量，且变量名前后建议加空格，有时用`{{ variable_name }}`才生效

**变量来源：**

1，`ansible`的`setup facts`远程主机的所有变量都可直接调用

2，通过命令行指定变量，优先级最高

```yaml
ansible-playbook -e varname=value
```

3，在`playbook`文件中定义

```yaml
vars:
  - var1: value1
  - var2: value2
```



##### 使用`setup`模块中变量

要求在`playbook`使用，不要用`ansible`命令调用

案例：使用`setup`变量

```yaml
vim var.yml
---
# var.yml
- hosts: websrvs
  remote_user: root
  
  tasks:
  - name: create log file
    file: name=/data/{{ ansible_nodename }}.log state=touch owner=wang mode=600
    
# 执行
ansible-playbook var.yml`
```



##### 在`playbook`中自定义临时变量

在`playbook`中有`-e`选项，它可以用于自定义变量

```yaml
ansible-playbook -e "username=user2 groupname=group2" var2.yml
```

范例：

1，创建用户和用户组

```yaml
vim var3.yml
---
- hosts: websrvs
  remote_user: root
  vars:
    - username: user1
    - groupname: group1
   
  tasks:
    - name: create group
      group: name={{ groupname }} state=present		# 未定义的变量名{{ groupname }}
    - name: create user
      user: name={{ username }} group={{ groupname }} state=present
      
#执行	username的值被替换为user2，groupname被替换为group2
ansible-playbook -e "username=user2 groupname=group2" var3.yml
```

2，安装`httpd`软件

```yaml
vim var.yml
---
- hosts: websrvs
  remote_user: root
  tasks:
    - name: install package
      yum: name={{ pkname }} state=present		# {{ pkname }}变量名,未定义

#执行
ansible-playbook -e pkname=httpd var.yml		# 通过 -e 定义，pkname的值被替换为httpd

#查看安装信息
ansible websrvs -m shell -a 'httpd -v'
```



##### 使用变量文件

可以在一个独立的`playbook`文件中定义变量,在另一个`playbook`文件中**引用变量文件中的变量**，比`playbook`中定义的变量优先级高

```yaml
vim vars.yml
---
# vars_files
package_name: vsftpd
service_name: vsftpd

vim var4.yml  
---
- hosts: appsrvs
  remote_user: root
  vars_files:         # vars_files: 表示指定调用的变量来自哪里  
    - vars.yml        # 调用变量来自于vars.vml  

  tasks:
    - name: install package
      yum: name={{ package_name }}
      tags: install
    - name: start service
      service: name={{ service_name }} state=started enabled=yes                                
```

执行成功

![image-20240823153214400](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240823153214400.png)

范例：

```yaml
vim vars2.yml
---
var1: httpd
var2: nginx

vim var5.yml
---
- hosts: web
  remote_user: root
  vars_files:
    - vars2.yml
  
  tasks:
    - name: create httpd log
      file: name=/app/{{ var1 }}.log state=touch
    - name: create nginx log
      file: name=/app/{{ var2 }}.log state=touch
```



#### 6.`template`模板

模板是一个文本文件，可以做为生成文件的模板，并且模板文件中还可嵌套`jinja`语法

##### `jinja2`语言

官网：https://jinja.palletsprojects.com/en/2.10.x/

`jinja2`语言使用字面量，有下面形式: 

```yaml
字符串：使用单引号或双引号
数字：整数，浮点数
列表：[item1,item2, ...]
元组：(item1,item2, ...)
字典：{key1:value1,key2:value2, ...}
布尔型：true/false
算术运算：+ - * /  //  %  **
比较操作：==   !=  >  >=  <  <=
逻辑运算符：and   or   not
```



###### 例子1：`template`

`template`功能：根据参考模块文件，动态生成相类似的配置文件。`template`文件必须存放于`template`目录下，且命名为`.j2`结尾

![image-20240826110355926](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826110355926.png)

范例：

1，在主控端安装`nginx`

```yaml
dnf install nginx -y
```

2，进入`/data/ansible`目录下

```yaml
#创建templates
mkdir templates
#将nginx.conf移动自templates下
mv /etc/nginx/nginx.conf /data/ansible/templates/nginx.conf.j2
```

![image-20240826103156256](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826103156256.png)

3，修改文件`nginx.conf.j2`的进程数为6

```yaml
#修改文件nginx.conf.j2
mkdir templates
vim templates/nginx.conf.j2
worker_processes {{ ansible_processor_vcpus }};	#进程数
```

![image-20240826103316478](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826103316478.png)

4，在`/data/ansible`下创建`templnginx.yml`文件，`/template`变量替换

```yaml
vim templnginx.yml
---
- hosts: websrvs
  remote_user: root
  
  tasks:
    - name: install nginx
      yum: name=nginx
    - name: template config to remote hosts
      template: src=nginx.conf.j2 dest=/etc/nginx/nginx.conf
    - name: start service
      service: name=nginx state=started enabled=yes
      
ansible-playbook templnginx.yml
```

5，测试

```
ansible-playbook -C templnginx.yml
```

不必理会该报错

![image-20240826103839890](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826103839890.png)

6，执行

```yaml
ansible-playbook templnginx.yml

# 针对某台特定主机
ansible-playbook templnginx.yml --limit 192.168.88.101
```

![image-20240826104023771](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826104023771.png)

7，查看`192.168.88.101`的进程数

```
ansible 192.168.88.101 -a 'pstree'
```

成功，进程数为6

![image-20240826104232836](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826104232836.png)



###### 例子2：`template`算术运算

`lscpu`命令：查看`cpu`核心数

范例：

```yaml
#也是修改nginx.conf.j2文件
vim /data/ansible/templates/vim nginx.conf.j2
worker_processes {{ ansible_processor_vcpus }};		#默认值，cpu核心个数
worker_processes {{ ansible_processor_vcpus**2 }};	
worker_processes {{ ansible_processor_vcpus+2 }};
```

1，修改`nginx下jijia2模板文件`

![image-20240826110746148](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826110746148.png)

2，修改`templnginx.yml`文件

**需要注意的一个常见问题是：在修改`nginx`下`jijia2`模板文件之前，`nginx的jijia2模板文件`已经启动了。意味着：修改模板文件并不会对原来启动的服务产生影响，同时会让新模板文件的需求不会生效。**

解决方案：

​	1，关闭虚拟机，重启(太麻烦了)

​	2，使用`handlers`和`notify`   `notify`当关注资源发生变化时，`handlers`会触发

```yaml
vim templnginx.yml

---
- hosts: websrvs
  remote_user: root

  tasks:
    - name: install nginx
      yum: name=nginx
    - name: template config to remote hosts
      template: src=nginx.conf.j2 dest=/etc/nginx/nginx.conf

      notify: restart nginx

    - name: start service
      service: name=nginx state=started enabled=yes

  handlers:
    - name: restart nginx
      service: name=nginx state=restarted
```

![image-20240826112456370](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826112456370.png)

3，测试并执行

```yaml
#测试
ansible-playbook -C templnginx.yml
#执行
ansible-playbook templnginx.yml
```

4，查看某个`ip`的进程数的进程数

`pstree`命令：树状结构查看所有进程

```
ansible 192.168.88.101 -a 'pstree'
```

![image-20240826112801252](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826112801252.png)

查看第1步修改的模板文件

![image-20240826113204566](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826113204566.png)



###### 例子3：`template`中使用流程控制`for`和`if`

`template`中也可以使用流程控制`for`循环和`if`条件判断，实现动态生成文件功能

1，在`jijia2`模块文件里，创建新的模块文件`nginx.conf2.j2 `

```yaml
# vim templates/nginx.conf2.j2 

{% for vhost in nginx_vhosts %}		#for循环，取出nginx_vhosts的每一个列表赋值给vhost
server {
	listen {{ vhost }};				#这是个单一值
}
{% endfor %}
```

![image-20240826154346049](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826154346049.png)

2，创建`templnginx2.yml`文件

```yaml
# vim templnginx2.yml
---
- hosts: 192.168.88.101
  remote_user: root
  vars:
          nginx_vhosts:		#这里的三个list对映模块文件的nginx_vhosts
                  - 81
                  - 82
                  - 83
  tasks:
          - name: template config
            template: src=nginx.conf2.j2 dest=/data/nginx.conf
```

![image-20240826154410503](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826154410503.png)

3，测试并执行`templnginx2.yml`

```yaml
#测试某台特定主机
ansible-playbook -C templnginx2.yml --limit 192.168.88.101
#执行
ansible-playbook templnginx2.yml --limit 192.168.88.101
```

![image-20240826154653658](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826154653658.png)

4，查看`192.168.88.101`这台主机

```yaml
ansible 192.168.88.101 -m shell -a 'more /data/nginx.conf'
```

![image-20240826154717708](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240826154717708.png)



##### `playbook`使用when

`when`语句，可以实现条件测试，如果需要根据变量，`facts`或此前任务的执行结果来做为某`task`执行与否的前提时。

要用到条件测试，通过在`task`后添加`when`子句即可使用条件测试,`jinja2`的语法格式

范例：

查看自己的操作系统是否为`redhat`系列

```yaml
ansible all -m setup -a 'filter=ansible_os_family'
```

```yaml
---
- hosts: websrvs
  remote_user: root
  tasks:
    - name: 'shutdown RedHat flavored systems'
      command: /sbin/shutdown -h now
      when: ansible_os_family == 'RedHat'
```

范例：

判断操作系统版本

```yaml
---
- hosts: websrvs
  remote_user: root
  
  tasks:
    - name: add group nginx
      tags: user
      user: name=nginx state=present
    - name: add user nginx
      user: name=nginx state=present group=nginx
    - name: install nginx
      yum: name=nginx state=present
    - name: restart nginx
      service: name=nginx state=restarted
      when: ansible_distribution_major_version == "8"	#当版本为8时启动服务
```



##### `playbook`使用with_items

迭代：当有需要重复性执行的任务时，可以使用迭代机制 (重复性任务反复执行)

对迭代项的引用，固定变量名为`item`

要在`task`中使用`with_items`给定要迭代的元素列表

**列表元素格式：**

- 字符串
- 字典

范例：

```yaml
# vim with_items.yml
---
- hosts: websrvs
  remote_user: root

  tasks:
     - name: add several users
       user: name={{ item }} state=present groups=wheel
       with_items:
               - testuser1
               - testuser2
#上面语句的功能等同于下面的语句
	- name: add user testuser1
	  user: name=testuser1 state=present groups=wheel
	- name: add user testuser2
	  user: name=testuser2 state=present groups=wheel
```

测试并执行

![image-20240827113241737](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827113241737.png)

![image-20240827113429031](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827113429031.png)

##### 例子：迭代嵌套子变量

在迭代中，还可以嵌套子变量，关联多个变量在一起使用

```yaml
# vim with_items2.yml
---
- hosts: websrvs
  remote_user: root

  tasks:
    - name: add some groups
      group: name={{ item }} state=present	#使用模块中变量
      with_items:	#迭代建立了3个组
        - g1
        - g2
        - g3
    - name: add some groups
      user: name={{ item.name }} group={{ item.group }} home={{ item.home }} state=present createhome=yes
      with_items:
              - { name: 'user1', group: 'g1', home: '/data/user1' }
              - { name: 'user2', group: 'g2', home: '/data/user2' }
              - { name: 'user3', group: 'g3', home: '/data/user3' }
```

![image-20240827145346285](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827145346285.png)

1，测试时，报出如下错误意为用户组不存在！

因为：创建组的`group`模块在`with_items2.yml`脚本内，只有当脚本运行时才会被创建。测试脚本不属于运行(即没有运行脚本)，所以才会报错。

解决：直接运行脚本即可，运行第一步会创建用户组。后续测试不会报错

```yaml
#用户组在脚本内创建时，测试脚本报出如下错误可以忽略
ansible-playbook -C with_items2.yml
```

![image-20240827150511754](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827150511754.png)

2，执行

```yaml
ansible-playbook with_items2.yml
```

![image-20240827150625064](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827150625064.png)

3，查看某个单一用户

```yaml
#查看user1
ansible websrvs -m shell -a 'id user1'
```

![image-20240827151031816](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827151031816.png)

确认用户信息

```yaml
ansible websrvs -m shell -a 'getend passwd user1'
```

![image-20240827151207356](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827151207356.png)

4，查看用户`home`目录

```yaml
ansible websrvs -m shell -a 'ls -l /data'
```

![image-20240827151344594](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827151344594.png)



#### 7.`roles`角色

角色用于层次性、结构化地组织`playbook`

运维复杂的场景:建议使用`roles`，代码复用度高

`roles`:多个角色的集合，可以将多个的`role`，分别放至`roles`目录下的独立子目录中

```yaml
roles/		#角色
	mysql/
	httpd/
	nginx/
	redis/
```

##### `ansible roles`目录编排

每个角色，以特定的层级目录结构进行组织

![image-20240827155934091](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827155934091.png)

##### `roles`目录结构及作用

```yaml
#playbook.yml
roles/
	tasks/			定义task，role的基本元素，至少应该包含一个名为main.yml的文件。其他文件需要在此文件中通过inclue进行包含
	files/			存放由copy或script模块等调用的文件
	templates/		template模块查找所需要模板文件的目录
	handlers/		至少应该包含一个名为main.yml的文件，其他文件需要在此文件中通过inclue进行包含
```

```yaml
defaults/:
作用: 存放默认变量。这些变量可以被外部或在 vars/ 目录中的变量覆盖。一般用于定义默认的配置参数。
文件: main.yml 是主要的变量文件。

files/:
作用: 存放静态文件，这些文件可以通过 copy 或 template 模块复制到目标节点上。文件是原封不动的二进制文件或文本文件。
文件: 例如 some_file.conf 可以是一个配置文件。

handlers/:
作用: 定义处理器（handlers）。处理器通常用于响应任务的通知，例如服务的重启操作。它们一般是基于某些任务完成后的触发。
文件: main.yml 存放处理器的主要逻辑。

meta/:
作用: 存放角色的元数据，定义角色的依赖、许可、作者信息等。可以在这里指定当前角色依赖的其他角色。
文件: main.yml 是元数据文件。

tasks/:
作用: 存放要执行的任务列表，这是角色的核心部分。任务定义了要在目标系统上执行的操作。
文件: main.yml 是默认任务列表文件，通常是这个目录的入口文件。

templates/:
作用: 存放 Jinja2 模板文件。这些模板文件可以在运行时通过变量替换生成目标配置文件。
文件: some_template.j2 可能是一个模板文件，可以在 playbook 中使用 template 模块进行渲染。

tests/:
作用: 用于测试角色的目录。你可以在这里放置测试用的 playbook 和 inventory 文件，用于验证角色的正确性。
文件: test.yml 是一个示例测试 playbook。

vars/:
作用: 存放变量文件。和 defaults/ 类似，但 vars/ 中的变量优先级更高，用于定义角色内部使用的重要变量。
文件: main.yml 是主要变量文件。
```

##### 创建role

创建role的步骤

- 创建以roles命名的目录
- 在roles目录中分别创建以各个角色名称命名的目录，如`webservers`等
- 在每个角色命名的目录中分别创建`files`，`handlers`,`meta`,`tasks`,`templates`和`vars`目录，用不到的目录可以创建为空目录，也可以不创建
- 在`playbook`文件中，调用各角色 

针对大型项目使用`Roles`进行编排 范例：`roles`的目录结构

![image-20240827172405023](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240827172405023.png)

##### `playbook`调用角色

**调用角色方法1：**

```yaml
---
- hosts: websrvs
  remote_user: root
  roles:			#playbook对应的角色
    - mysql
    - memcached
    - nginx
```

**调用角色方法2：**

键`role`用于指定角色名称，后续的k/v用于传递变量给角色

```yaml
---
- hosts: all
  remote_user: root
  roles:
    - mysql								#playbook对应的角色
    - { role: nginx,username: nginx }	#临时传递角色变量
```

**调用角色方法3：**

基于条件测试实现角色调用

```yaml
---
- hosts: all
  remote_user: root
  roles:							# when: 系统版本为Centos7时才执行角色
    - { role: nginx,username: nginx,when: ansible_distribution_major_version == '7' }
```

##### `roles`中`tags`使用

```yaml
# nginx-role.yml
---
- hosts: websrvs
  remote_user: root
  roles:
  	- { role: nginx,tags: [ 'nginx','web' ],when: ansible_distribution_major_version =='6'}
  	- { role: httpd,tags: [ 'httpd','web' ] }
  	- { role: mysql,tags: [ 'mysql','db' ] }
  	- { role: mariadb,tags: [ 'mariadb','db' ] }
  	
ansible-playbook --tags="nginx,httpd,mysql" nginx-role.yml
```

![image-20240828102632224](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828102632224.png)



#### 8，实战案例

准备工作

```yaml
#删除软件 mariadb-server httpd nginx mysql-server vsftpd memcached 
#没有也不会报错
ansible all -m shell -a 'yum -y remove mariadb-server httpd nginx mysql-server vsftpd memcached'

#在 /data/ansible 创建roles文件夹
#roles文件夹里面会根据不同的应用创建独立文件夹，每一个软件部署都创建对应独立文件夹
mkdir roles

#查看端口
ss -ntl
#查看某个软件的配置文件
rpm -ql nginx
```



##### 案例1：实现`httpd`角色

1，创建`httpd`软件部署文件夹

```yaml
#在roles下创建httpd软件部署文件夹
mkdir httpd
cd httpd
mkdir {tasks,files,templates} -p;
#或者
cd roles
mkdir httpd/{tasks,files,templates} -p;		#在httpd文件夹下，同时创建多个同级文件夹
```

目录结构

![image-20240828105647139](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828105647139.png)



2，创建角色相关文件

```
 安装软件			install.yml
 修改配置文件		   config.yml
 部署数据文件(网页)   index.yml
 启动服务			service.yml
```

```yaml
1，安装软件(软件安装多在tasks目录下)
vim roles/httpd/tasks/install.yml
---
- name: install httpd package
  yum: name=httpd
```

```yaml
2，拷贝配置文件(修改配置文件多在files目录下)
#修改配置文件需要将httpd的配置文件拷贝自 roles/httpd/files/ 目录下,如果没有httpd软件需要安装
cp /etc/httpd/conf/httpd.conf roles/httpd/files/httpd.conf

# vim roles/httpd/tasks/config.yml
---
- name: config file
  copy: src=httpd.conf dest=/etc/httpd/conf/ backup=yes
  notify: restart
```

```yaml
3，部署数据文件(网页) (部署数据文件多在tasks目录下)
vim roles/httpd/tasks/index.yml
---
- name: index.html
  copy: src=index.html dest=/data/httpd/html/

#这里部署数据文件用我们自己定义的网页，所以需要在files目录下创建自己定义html文件
vim roles/httpd/files/index.html 
<h1>welcome to wukong</h1>
```

```yaml
4，启动服务(启动服务多在tasks目录下)
vim roles/httpd/tasks/service.yml
---
- name: start service
  service: name=httpd state=started enabled=yes
```

第2步目录结构：

![image-20240828113835797](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828113835797.png)



3，**创建`mian.yml`文件，确定其`tasks`目录下文件执行顺序。也是角色文件的总入口，并且该`yml`文件必须为`mian.yml`**

- `mian.yml`是约定熟成的，叫这个名字会使得角色的结构更标准化和易于维护
- 对于文件放置的位置，`main.yml` 通常是放在 `tasks/` 目录下，这也是 `Ansible` 的默认查找路径。

```yaml
1,在tasks创建main.yml文件并确定角色相关文件执行顺序
vim roles/httpd/tasks/main.yml
---
#这是执行次序，从上向下：安装软件，修改配置，部署数据，启动服务
- include: install.yml
- include: config.yml
- include: index.yml
- include: service.yml

这里修改配置文件中的config.yml涉及到了 notify:
这也意味着需要使用到handlers
```

![image-20240828144130011](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828144130011.png)

```yaml
#需要在handlers目录下创建一个main.yml文件 
作为config.yml文件中notify的handlers(要操作的对象和要调用的操作)
并且config.yml中notify的描述名字和handlers/main.yml中name的描述文字是匹配的

vim roles/httpd/handlers/main.yml
---
- name: restart
  service: name=httpd state=restarted
```

第3步目录结构：

![image-20240828145128376](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828145128376.png)



4，调用`httpd`角色，需要写一个单独的用于调用`playbook`

**名字叫什么无所谓，但是一定要和`roles`文件夹是平级关系**

```yaml
#单独的`playbook`用于调用角色
vim /data/ansible/role_httpd.yml
---
# httpd role
- hosts: websrvs			应用在[websrvs]主机清单上
  remote_user: root			以root身份运行
  
  roles:					角色
    - role: httpd			1个角色是httpd
#运行playbook
ansible-playbook /data/ansible/role_httpd.yml
```



**5，补充：因为是`Centos8`系统，在安装`httpd`时,不会自动创建用户和用户所属组，所以需要我们手动创建**

1，创建组和用户

```yaml
# vim roles/httpd/tasks/group.yml
---
- name: create apache group
  group: name=apache system=yes gid=140
  
# vim roles/httpd/tasks/user.yml 
---
- name: create apache user
  user: name=apache system=yes uid=140 home=/data/httpd shell=/sbin/nologin group=apache
```

2，添加至角色文件总入口

```yaml
# vim roles/httpd/tasks/main.yml
- include: group.yml
- include: user.yml
- include: install.yml
- include: config.yml
- include: index.yml
- include: service.yml
```

3，执行第4步运行`bookplay`

```yaml
ansible-playbook role_httpd.yml
```

![image-20240828165902842](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828165902842.png)

4，输入`systemctl status httpd.service`发现服务启动成功

​	如果启动失败：

​			1，查看服务端口情况，是否被修改或者被占用

​			2，查看防火墙是否被停止

![image-20240828170508975](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828170508975.png)

查看网页

![image-20240828172352995](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240828172352995.png)



##### 案例2：实现`nginx`角色

1，创建`nginx`部署文件夹

```shell
mkdir roles/nginx/{tasks,handlers,templates,vars} -p
```

![image-20240829103425267](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829103425267.png)



2，安装软件，拷贝配置文件，配置数据(网页)，启动服务 

```yaml
vim tasks/main.yml
---
- include: install.yml
- include: config.yml
- include: index.yml
- include: service.yml
```

```yaml
1，安装软件
#vim roles/nginx/tasks/install.yml 
---
- name: install
  yum: name=nginx
```

```yaml
2，拷贝配置文件,不同操作系统有不同版本
#vim roles/nginx/tasks/config.yml
---
- name: config file for centos8
  template: src=nginx8.conf.j2 dest=/etc/nginx/nginx.conf
  when: ansible_distribution_major_version='8'
  notify: restart
  
#这里还得拷贝nginx配置文件至模板
cp /etc/nginx/nginx.conf roles/nginx/templates/nginx8.conf.j2
```

软件配置文件拷贝至模块目录下，调用路径和`copy`路径相同

![image-20240829155520032](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829155520032.png)



```yaml
3，配置网页数据，这里直接拷贝httpd的网页
---
name: index.html
# 这里是跨项目的文件调用，纯真的模块化思想，不必重复创建
copy: src=roles/httpd/files/index.html dest=/usr/share/nginx/html/
```

```yaml
4，启动服务
#vim roles/nginx/tasks/service.yml
---
- name: start service
  service: name=nginx state=started enabled=yes
```



3，创建调用角色的`main.yml`文件，该文件要和`roles`处于同一目录下

```yaml
#vim role_nginx.yml
---
- hosts: websrvs
  roles:
          - role: nginx
```

4，调用`ansible-playbook`启动服务

```yaml
ansible-playbook role_nginx.yml
```

![image-20240829114252185](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829114252185.png)



**5，补充：`centos8`安装`nginx`时会自己创建用户和所属组，所以不需要我们在`tasks/`目录下创建**

如果出现如下服务器启动报错，请看参考文献：https://blog.csdn.net/li1325169021/article/details/118462921#:~:text=%E8%BE%93%E5%85%A5nginx%20-t%20%E5%91%BD%E4%BB%A4%EF%BC%8C%E5%A6%82%E6%9E%9C%E5%8F%8D%E5%9B%9E%20successful%E8%A1%A8%E7%A4%BA%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6%E6%97%A0%E9%94%99%E8%AF%AF%EF%BC%8C%E5%90%A6%E5%88%99%E8%AF%B4%E6%98%8E%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6%E6%9C%89%E9%94%99%E8%AF%AF%E3%80%82

![image-20240829114534967](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829114534967.png)



##### 案例3：实现`memcached`角色

1，创建`memcached`部署文件

```shell
mkdir roles/memcached/{tasks,templates} -p
```

![image-20240829152400855](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829152400855.png)

2，安装软件，拷贝配置文件，启动服务

```yaml
#vim roles/memcached/tasks/install.yml
---
- include: install.yml
- include: config.yml
- include: service.yml
```

```yaml
1，安装软件
#vim roles/memcached/tasks/install.yml
---
- name: install
  yum: name=memcached
```

```shell
2，拷贝配置文件
#vim roles/memcached/tasks/config.yml
---
- name: config file
  template: src=memcached.j2 dest=/etc/sysconfig/memcached
  
拷贝模板文件：把memcached配置文件copy至templates模板文件目录下
cp /etc/sysconfig/memcached roles/memcached/templates/memcached.j2
```

![image-20240829154033235](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829154033235.png)



```yaml
3，启动服务
#vim roles/memcached/tasks/service.yml
---
name: service
service: name=memcached state=started
```

最后目录结构

![image-20240829161051539](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829161051539.png)

3，创建角色调用文件`main.yml`，该文件要与`roles`处于同一目录下

```yaml
#vim role_memcached.yml
---
- hosts: websrvs
  roles:
          - role: memcached
```

4，运行

```yaml
ansible-playbook role_memcached.yml
```

![image-20240829155246911](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829155246911.png)

5，查看服务

```shell
# 查看端口号
ss -ntl
```

`memcached`服务的端口号是`11211`

![image-20240829161259871](C:\Users\27252\Desktop\桌面图标\常用夹\Ansible\Ansible图\image-20240829161259871.png)



##### 学习网站

官网网站：https://galaxy.ansible.com/ui/

中文站：http://ansible.com.cn/
