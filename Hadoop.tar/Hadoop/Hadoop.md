###### `hadoop`安装及配置

安装

https://www.bilibili.com/video/BV1CU4y1N7Sh/?p=23&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14

配置

https://www.bilibili.com/video/BV1CU4y1N7Sh/?p=25&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14



###### `hadoop`架构

```
HDFS 分布式文件存储
	​ 主角色 NameNode

	​ 从角色 DataNode

	​ 主角色辅助角色 SecondaryNameNode

MapReduce 分布式数据处理

YARN 集群资源管理，任务调度

	​ 主角色 ResourceManager

	​ 从角色 NodeManager
```

![image-20241008150144285](./Hadoop%E5%9B%BE/image-20241008150144285.png)

1，如何理解两个集群逻辑上分离？

```
 HDFS集群：主角色NN，主角色辅助角色SNN，从角色DN
 YARN集群：主角色RM，从角色，NM
```

 `逻辑上分离指：同一台机器上的HDFS集群和YARM集群 角色(角色指独立进程)互相不受依赖`

2，如何理解两个集群物理上在一起？

 `物理上在一起指：不同角色进程在物理层面可以部署在一台机器上`

3，为什么没有`MapReduce`集群？有这样的说法吗？

 `MapReduce是计算框架，是代码层面主键，没有MapReduce集群这种说法`



###### `hadoop`目录结构

![image-20241008152430649](./Hadoop图/image-20241008152430649.png)

```shell
bin  管理脚本和使用脚本的目录，可以直接使用这些脚本管理和使用hadoop
etc  hadoop配置文件所在目录
include  对外提供的编程库头文件(具体动态库和静态库在lib目录中)
lib  该目录包含了hadoop对外提供的编程动态库和静态库，与include目录中的头文件结合使用
libexec  各个服务对用的shell配置文件所在目录，可用于配置日志输出，启动参数
sbin   hadoop管理脚本目录，主要包含HDFS和YARN中各类服务的启动/关闭
share  hadoop各个模块编译后的jar包所在目录
```



###### `hadoop`集群启停命令

**1,手动逐个进程启停**

每台机器上每次手动启动关闭一个角色进程，可以精准控制每个进程启停，避免群起群停

`HDFS`集群

```shell
hdfs -daemon start|stop namenode|datanode|secondarynamenode
```

`YARN`集群

```shell
yarn -daemon start|stop resourcemanager|nodemanager
```

**2,shell脚本一键启停**

配置好机器之间的ssh免密登陆和workers文件

`HDFS`集群

```shell
start-dfs.sh
stop-dfs.sh
```

`YARN`集群

```shell
start-yarn.sh
stop-yarn.sh
```

`hadoop`集群

```shell
start-all.sh
stop-all.sh
```



启动完成后使用`jps`命令查看进程是否启动成功

查看`Hadoop`启动日志路径`/export/server/hadoop-3.3.0/logs/`



**3.查看集群的web页面**

```shell
其中namenode host是namenode运行所在机器的主机名或者ip
http://namenode host:9870

输入主机IP＋端口
192.168.88.151:9870
```

`HDFS`集群

http://192.168.88.151:9870

`YARN`集群

http://192.168.88.151:8088



###### `hadoop`中`HDFS`命令操作

1，查看根目录下文件信息

```shell
hadoop fs -ls /
```

shell命令目录下

![image-20241008165412440](./Hadoop图/image-20241008165412440.png)

web目录下

![image-20241008165518982](./Hadoop图/image-20241008165518982.png)

2，将文件上传至`/itcast`目录下

```shell
hadoop fs -put anaconda-ks.cfg /itcast
```



3，在本地主机上创建一个`1.txt`并写入1，上传至`HDFS集群`根目录下

```shell
echo 1>1.txt
hadoop fs -put 1.txt
```

![image-20241008170149363](./Hadoop图/image-20241008170149363.png)



1,执行`MapReduce`的时候，为什么首先请求`YARN`？

`因为YARN是Hadoop生态系统中的资源管理框架，负责管理计算资源并协调作业的执行`

2，`MapReduce`看上去好像是两个阶段？先`Map`在`Reduce`?

`先Map阶段(数据映射为键值对)，在进行Shuffle 和 Sort 阶段（洗牌和排序），最后Reduce 阶段（按键聚合处理）`

3，处理小数据的时候，`MapReduce`速度快吗？

`不会，MapReduce适合处理大规模数据集`



##### `HDFS`分布式文件系统基础(命令)

数据：指存储内容本身，比如文件，视频，图片等。这些数据底层最终存储在磁盘等存储介质上。

元数据：元数据又称之为解释性数据，记录数据的数据；

文件系统元数据指：文件大小，最后修改时间，底层存储位置，属性，所属用户，权限等信息



###### `HDFS`shell操作

```
hadoop fs -ls file:///				操作本地文件系统
hadoop fs -ls hdfs://node1:8020/	操作HDFS分布式文件系统
hadoop fs -ls /						直接根目录，没有指定协议 将加载读取 fs.defaultFS值
```

查看操作`HDFS`分布式文件系统目录

![image-20241009103227794](./Hadoop图/image-20241009103227794.png)

###### 1，创建文件夹

```shell
hadoop fs -mkdir [-p] <path>...
	path 为待创建目录
	-p选项，沿着路径创建父目录

# 在HDFS文件系统根目录下创建itcast文件夹
hadoop fs -mkdir /itcast
```

###### 2，查看指定目录下内容

```shell
hadoop fs -ls [-h] [-R] [<path>...]
	path 指定目录路径
	-h 人性化显示文件size
	-R 递归查看指定目录及其子目录

# 显示HDFS文件系统根目录下文件大小
hadoop fs -ls -h /
```

###### 3，上传文件到`HDFS`指定目录下

```shell
hadoop fs -put [-f] [-p] <localsrc>...<dst>
	-f 覆盖目标文件(目标文件已存在)
	-p 保留访问和修改时间，所有权和权限
	localsrc 本地文件系统(客户端所在机器)
	dst 目标文件系统(HDFS)
	
# 将本地文件系统下的zookeeper.out文件 上传至 HDFS文件系统itcast目录下
hadoop fs -put zookeeper.out /itcast
```

复杂写法: 将本地文件系统中的2.txt上传至HDFS文件系统的itcast目录下

```shell
hadoop fs -put file:///root/2.txt hdfs://node1:8020/itcast/  或  hadoop fs -put file:///root/2.txt hdfs://192.168.88.151:8020/itcast/
```

![image-20241009111855877](./Hadoop图/image-20241009111855877.png)

###### 4，查看`HDFS`文件内容

```shell
hadoop fs -cat <src>...
	读取指定文件全部内容，显示在标准输出控制台
	注意：对于大文件内容读取，慎用

# 查看HDFS文件系统根目录下itcast目录下文件信息
hadoop fs -cat /itcast/zookeeper.out
```

###### 5，下载`HDFS`文件

```shell
hadoop fs -get [-f] [-p] <localsrc>...<localdst>
	从HDFS文件系统下载文件到本地文件系统指定目录，localdst必须是目录
	-f 覆盖目标文件(目标文件已存在)
	-p 保留访问和修改时间，所有权和权限

# 将HDFS文件系统itcast目录下的2.txt下载至本地文件系统/root目录下
hadoop fs -get /itcast/2.txt /root
# 下载时还可以改名
hadoop fs -get /itcast/2.txt /root/2_new.txt
```

复杂写法: 将HDFS文件系统的itcast目录下的2.txt下载至本地文件系统/root目录下

```shell
hadoop fs -get hdfs://192.168.88.151:8020/itcast/2.txt file:///root/
```

![image-20241009112432611](./Hadoop图/image-20241009112432611.png)

###### 6，拷贝`HDFS`文件

```shell
hadoop fs -cp [-f] <localsrc>...<dst>
	-f 覆盖目标文件(目标文件已存在)
	localsrc 本地文件系统(客户端所在机器)
	dst 目标文件系统(HDFS)
```

###### 7，追加数据到`HDFS`文件中

```shell
hadoop fs -appendToFile <localsrc>...<dst>
	将所有给定本地文件的内容追加到给定HDSF文件系统的文件中
	dst如果文件不存在，将创建该文件
	如果<localsrc>为-，则输入为从标准输入中读取

# 在本地文件系统中创建三个txt文件
echo 1 > 1.txt
echo 2 > 2.txt
echo 3 > 3.txt

# 将本地文件系统中的 1.txt上传至HDFS文件系统根目录下
hadoop fs -put 1.txt /

# 将本地文件系统剩余的两个txt文件内容 追加至 HDFS文件系统更目录下的1.txt内容后
# 可以同时追加多个文件
hadoop fs -appendToFile 2.txt 3.txt /1.txt
```

![image-20241009144900408](./Hadoop图/image-20241009144900408.png)

###### 8，`HDFS`数据移动操作

```shell
hadoop fs -mv <localsrc>...<dst>
	移动文件到指定文件夹下
	可以使用命令移动数据，重命令文件的名称
	localsrc 本地文件系统(客户端所在机器)
	dst 目标文件系统(HDFS)
```



##### `HDFS`集群角色与职责

![image-20241009153518887](./Hadoop图/image-20241009153518887.png)

```
主角色 namenode
	NameNode是hadoop分布式文件系统的核心,架构中的主角色。
	NameNode维护和管理文件系统元数据。包括名称空间目录树结构，文件和快的位置信息。
```

`namenode是访问HDFS的唯一入口`

![image-20241009155131888](./Hadoop图/image-20241009155131888.png)



```
从角色 datanode
	DataNode是hadoop分布式文件系统的从角色，负责具体的数据快存储
	DataNode的数量决定了HDFS集群的整体数据存储能力。通过和NameNode配合维护着数据快
```

`实际工作中，扩容集群其实就是增加datanode的节点`

![image-20241009155400618](./Hadoop图/image-20241009155400618.png)



```
主角色辅助角色 secondarynamenode
	secondarynamenode 充当 namenode的辅助节点，但不能代替namenode
	主要是帮助主角色进行元数据文件的合并动作。
```



##### `HDFS`写数据流程

`HDFS分布式文件系统采用三副本文件备份`

**核心概念 `Pipeline`管道**

- `Pipeline`中文翻译为管道。这是`HDFS`在上传文件写数据过程中采用的一种数据传输方式
- 客户端将数据块写入第一个数据节点，第一个数据节点保存数据之后在将快复制到第二个数据节点，后者保存后将其复制到第三个数据节点。

![image-20241009160324057](./Hadoop图/image-20241009160324057.png)

**核心概念 `ACK`应答响应**

- `ACK`即是确认字符，在数据通信中，接受方给发送方的一种传输控制字符。表示发送来的数据已确认接收无误。
- 在`HDFS Pipeline`管道传输数据的过程中，传输的反方向会进行`ACK`校验。

![image-20241009161815614](./Hadoop图/image-20241009161815614.png)

**核心概念 默认3副本存储策略**

默认副本存储策略是由`BlockPlacementPolicyDefault`类指定

- 第1副本：优先客户端本地，否则随机
- 第2副本：不同于第一块副本的不同机架
- 第3副本：第二块副本相同机架不同机器



##### `MapReduce`框架

###### 1，理解`MapReduce`思想

- Map表示第一阶段，负责"拆分":即把复杂任务分解为诺干个"简单的子任务"来并行处理。可以进行拆分的前提是这些小任务可以并行计算，彼此间几乎没有依赖关系。
- Reduce表示第二阶段，负责"合并":即对map阶段的结果进行全局汇总。
- 这两个阶段合起来正是`MapReduce`的思想体现

![image-20241009171632848](./Hadoop图/image-20241009171632848.png)

###### 2，分布式计算概念

`mapReduce是一个分布式计算框架`，适合海量数据的离线处理

分布式计算是一种计算方法，和集中式计算是相对的

`分布式计算将该应用分解成许多小的部分，分配给多台计算机进行处理。`这样可以节约整体计算时间，提高计算效率



**`mapReduce`局限性(适合用于离线的大量数据计算)**

- 实时计算性能差

​	`mapReduce`主要应用于离线作业，无法做到秒级的数据响应

- 不能进行流式计算

​	流式计算特点是数据是源源不断的计算，并且数据是动态的；而`mapReduce`作为一个离线计算框，主要针对静态数据集，数据是不能动态变化的。



**`mapReduce`进程**

`mapReduce`程序在分布式运行时有三类

- `MRAppMaster` 负责整个MR程序的过程调度及状态协调
- `MapTask` 负责map阶段的整个数据处理流程
- `ReduceTask` 负责reduce阶段的整个数据处理流程



**阶段组成**

- 一个`mapReduce`编程模型中只能包含一个`Map`阶段和一个`Reduce`阶段，或者只有`Map`阶段
- 如果用户的业务逻辑非常复杂，那就只能多个`MapReduce`程序串行运行

![image-20241010111438412](./Hadoop图/image-20241010111438412.png)

- 不能出现多个`Map`阶段，多个`Reduce`阶段这种情况

![image-20241010111612809](./Hadoop图/image-20241010111612809.png)



官方案例：单词统计

https://www.bilibili.com/video/BV1CU4y1N7Sh/?p=43&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14



###### 3，执行流程和Shuffle机制

![image-20241010152347308](./Hadoop图/image-20241010152347308.png)

**Map阶段执行流程**

- 第一阶段：把输入目录下文件按照一定标准逐个进行`逻辑切片`，默认`Split size = Block size(128)`，每一个切片由一个`MapTask`处理。(这里逻辑切片大小默认等于底层文件快的大小，如果文件不足128M,文件本身有多大，块就有多大)。
- 第二阶段：对切片中的数据按照一定的规则读取解析返回键值对。`默认是按行读取数据`。key是每一行的起始位置偏移量，value是本行的文件内容。
- 第三阶段：调用`Mapper`类中的`map`方法处理数据，每读取解析出来一个键值对，就调用一次`map`方法。

- 第四阶段：按照一定的规则对`Map`输出的键值对进行分区`partition`。默认不分区，因为只有`reducetask`

- 第五阶段：`Map`输出数据写入内存缓冲区，达到比例溢出到磁盘上。溢出`spill`的时候根据`key`进行`排序sort`，默认根据`key`值字典排序。
- 第六阶段：对所有溢出文件进行最终的`merge`合并，成为一个文件。



**Reduce阶段执行流程**

第一阶段：`ReduceTask`会主动从`MapTask复制拉取`属于需要自己处理数据。

第二阶段：把拉取来数据，全部进行`合并merge`，即把分散的数据合并成一个大的数据。在对合并后的数据`排序`。

第三阶段：是对排序的键值对`调用reduce方法`。键相等的键值对调用一次reduce方法。最后把这些输出的键值对写入到`HDFS`文件中



**Shuffle机制**

`shuffle`的本意是洗牌，洗混的意思。把一组有规则的数据尽量打乱成无规则的数据。

而在`MapReduce`中，`shuffle`更像是洗牌的逆过程，指的是`将Map端的无规则输出按指定的规则 “打乱” 成具有一定规则的数据，以便reduce端接收处理`。

一般把从`Map产生输出开始到Reduce取得数据作为输入之前的过程称作shuffle`。

**Shuffle机制的缺点**

​    Shuffle是`MapReduce`程序的核心与精髓，是`MapReduce`的灵魂所在。

​    Shuffle也是`MapReduce`被诟病最多的地方。`MapReduce`相比较于`Spark`，`Flink`计算引擎慢的原因，跟`Shuffle`机制有很大关系。

​    Shuffle中`频繁涉及到数据在内存与磁盘之间的多次往复`。



参考文献https://www.bilibili.com/video/BV1CU4y1N7Sh/?p=44&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14

https://www.bilibili.com/video/BV1CU4y1N7Sh/?p=45&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14

https://www.bilibili.com/video/BV1CU4y1N7Sh/?p=46&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14



##### Hadoop YARN

![image-20241011154955706](./Hadoop图/image-20241011154955706.png)

YARN是一种新的`Hadoop`资源管理器，另一种资源协调者。

`YARN是一种通用资源管理系统和调度平台`，可为上层应用提供统一的资源管理和调度。

**YARN功能说明**

资源管理系统：集群的硬件资源，和程序运行相关，比如`内存,CPU`等（这里`磁盘由HDFS`来管理）

调度平台：多个程序同时申请计算`资源如何分配`,调度的规则（算法）

通用：不仅仅支持`MapReduce`程序,`理论上支持各种计算程序`。YARN不关心你在干什么，只关系你要资源；在有的情况下给你，用完后还我。

**YARN概述**

可以把`Hadoop YARN`理解为相当于一个分布式的操作系统平台，而`MapReduce`等计算程序则相当于运行于操作系统之上的应用程序，`YARN为这些程序提供运算所需的资源(内存,CPU)`

`Hadoop`能有今天的地位，`YARN`是功不可没的。因为有了`YARN`，更多计算框架可以接入到`HDFS`中,而不单单是`MapReduce`，`正是因为YARN的包容，使得其他计算框架能专注于计算性能的提升`



###### 1，Hadoop YARN架构和主键

![image-20241011164755707](./Hadoop图/image-20241011164755707.png)

![image-20241011170050169](./Hadoop图/image-20241011170050169.png)

###### 2，程序提交YARN交互流程

- MR作业提交  Client --> RM
- 资源的申请  `MrAppMaster` --> RM
- MR作业状态汇报 `Container(Map Reduce Task) --> Container(MrAppMaster)`
- 节点的状态汇报 NM --> RM

**整体概述**

当用户向`YARN`中提交一个应用程序后，YARN将分两个阶段运行该应用程序。

第一阶段是 客户端申请资源启动运行本次程序的`ApplicationMaster`

第二阶段是 由`ApplicationMaster`根据本次程序内部具体情况，为它申请资源，并监控它的整个运行过程，直到运行完成

**MR提交YARN交互流程**

- 第1步: 用户通过客户端向`YARN`中`ResourceManager`提交应用程序(比如`hadoop jar`提交MR程序)
- 第2步: `ResourceManager`为该应用程序分配第一个`Container`（容器）,并与对应的`NodeManager`通信,要求它在这个`Container`中启动这个应用程序的`ApplicationMaster`
- 第3步：`ApplicationMaster`启动成功之后，首先向`ResourceManager`注册并保持通信，这样用户可以直接通过`ResourceManager`查看应用程序的运行状态（处理了百分之几）
- 第4步: AM为本次程序内部的各个`Task`任务向RM申请资源，并监控它的运行状态
- 第5步：一旦`ApplicationMaster`申请到资源后，便与对应的`NodeManager`通信，要求它启动任务
- 第6步: `NodeManager`为任务设置好运行环境后，将任务启动命令写到一个脚本中，并通过运行该脚本启动任务
- 第7步: 各个人物通过某个`RPC`协议向`ApplicationMaster`汇报自己状态和进度，以让`ApplicationMaster`随时掌握各个人物的运行状态，从而可以在任务失败时重新启动任务。在应用程序运行过程中，用户可随时通过`RPC`向`ApplicationMaster`查询应用程序的当前运行状态
- 第8步：应用程序运行完成后，`ApplicationMaster`向`ResourceManager`注销并关闭自己

![image-20241024161850566](./Hadoop图/image-20241024161850566.png)



#### Apache Hive

###### 1，数据仓库基本概念

数据仓库(简称数仓,`DW Data Warehouse`)，`是一个用于存储 分析 报告的数据系统`

数据仓库的目的是构建面向分析的集成化数据环境，分析结果为企业提供决策支持

主要特征：面向主题，集尘性，非易失性，时变性

**数仓专注分析**

数据仓库`本身并不"生产"任何数据`，其数据来源于不同外部系统

同时数据仓库自身`也不需要"消费"任何的数据`，其结果开放给各个外部应用使用



###### 2，什么是Apache Hive

- Apache Hive是建立在`Hadoop`之上的开源`数据仓库`系统，可以将存储在`Hadoop`文件中`的结构化，半结构化数据文件映射为一张数据表`，基于表提供了一种类似`SQL`的查询模型，称为`Hive查询语言(HQL)`,用于访问和分析存储在`Hadoop`文件中的大型数据集。
- Hive核心是将`HQL转换为MapReduce`程序，然后将程序提交到`Hadoop`集群执行



###### 3，Hive能将数据文件映射成为一张表

- `Hive`能将数据文件映射成为一张表，这个映射是指什么？
- `Hive`软件本身到底承担了什么功能职责？

`Hive`中`能够写sql处理的前提是针对表，而不是针对文件`，因此需要将文件和表之间的对应关系描述记录清楚，映射信息专业的叫法称之为`元数据信息(元数据是指用来描述数据的数据 metadata)`

![image-20241025151505925](./Hadoop图/image-20241025151505925.png)

在`HDFS`文件系统上有一个文件，路径为`/data/china_user.txt`



###### 4，Hive自带的两个客户端

![image-20241025165709901](./Hadoop图/image-20241025165709901.png)

第一代：`Hive CLI`，可以直接启动`metastore`服务，访问元数据

```shell
$HIVE HOME/bin/hive 	是一个shellUtil工具
```

第二代：`Beeline CLl`，得先通过`hiveserver2`服务，再去通过`metastore`服务，访问元数据

```shell
$HIVE HOME/bin/binline 	是JDBC客户端（推荐使用第二代客户端）
```



##### 启动Hive

**前台启动**，进程会一直占据终端，`ctrl + c`结束进程，服务关闭。

日志文件位置：出现在终端屏幕上

```shell
# 启动命令
/export/server/apache-hive-3.1.2-bin/bin/hive --service metastore
```

![image-20241025163935308](./Hadoop图/image-20241025163935308.png)



**后台启动**，把`Hive`当作一个进程挂在后台去运行，输入日志信息在`/root`目录下`nohup.out`

使用 kill -9 [进程号] 结束进程

```shell
# 启动命令
nohup /export/server/apache-hive-3.1.2-bin/bin/hive --service metastore &
```

![image-20241025164349776](./Hadoop图/image-20241025164349776.png)

日志文件位置

![image-20241025164748372](./Hadoop图/image-20241025164748372.png)

**完整启动命令**

`hiveServer2`通过`metastore`服务读写元数据

在远程模式下：想使用`Beeline CLl`客户端，在启动`metastore`服务基础上才能启动`hiveserver2`服务

```shell
# 启动 metastore服务
nohup /export/server/apache-hive-3.1.2-bin/bin/hive --service metastore &
# 启动 HiveServer2服务
nohup /export/server/apache-hive-3.1.2-bin/bin/hive --service hiveserver2 &

# 启动连接，文件路径后beeline  beeline改hive就是第一代客户端
/export/server/apache-hive-3.1.2-bin/bin/beeline

# ！connect 		表示连接
# jdbc:hive2:	 表示协议前缀
# node1:10000	 地址在node1上,端口是10000
! connect jdbc:hive2://node1:10000
```

连接在node1上，端口默认端口10000

![image-20241025172314445](./Hadoop图/image-20241025172314445.png)

参考文献：

https://www.bilibili.com/video/BV1CU4y1N7Sh?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=62

https://www.bilibili.com/video/BV1CU4y1N7Sh?spm_id_from=333.788.videopod.episodes&vd_source=da0ca5a74459b110b3a6da903d245e14&p=63



###### 5,`Hive sql`

**案例：如何把一份结构化文件映射为数据表**

1，创建数据表作为映射表

```sql
create table if not exists t_archer
(
    id     int comment "ID编号",
    name   string comment "名称",
    hp_max int comment "最大生命",
    mp_max int comment "最大法力",
    attack_max int comment "最高物攻",
    defense_max string comment "攻击范围",
    role_main string comment "主要定位",
    role_assist string comment "次要定位"
)
row format delimited
fields terminated by "\t";  --字段之间的分隔符是tab键，制表符
```

2，将文件上传至表对应的目录下

![image-20241028160734233](./Hadoop图/image-20241028160734233.png)

3，数据没问题，创建的数据库没问题。其实就映射成功了



###### 6,Hive底层运行机制

在查看`hadoop hive`底层源数据时，会发现显示不了中文

Hive底层运行机制会把源数据(记录数据的数据)，保存在mysql中，mysql默认编码为latin1，不支持中文。需要改为UTF8

```sql
# mysql使用comment注释信息，不支持中文
role_assist string comment "次要定位"
```



##### Hive SQL-DML-Load加载数据

load含义为：加载，装载

所谓加载是指：将数据文件移动到与Hive表对应的位置，移动时时纯`复制，移动`操作

纯复制，移动指在数据load加载到表中时,Hive不会对表中的数据内容进行任何转换，任何操作

```sql
语法规则
	load data [local] inpath 'FilePath' [overwrite] into Table 'Table_name';
	local 是可选参数,表示本地
	overwrite 是可选参数,表示覆盖表中数据
```

local本地指的是：`hiveserver2服务所在机器的本地Linux文件系统`,不是Hive客户端所在的本地文件系统

本地加载数据时，是纯`复制`操作

HDFS加载数据是，是纯`移动`操作



###### 案例：local本地文件系统上传

1，建表student_local 用于演示从本地加载数据

```sql
create table student_local(num int,name string,sex string,age int,dept string) row format delimited fields terminated by ',';
```

2，把所需要数据在linux上传

![image-20241029162718590](./Hadoop图/image-20241029162718590.png)

3，使用`Hive`官方提供的文件上传方式

```shell 
 load data local inpath '/root/hivedata/students.txt' into table itcast.student_local;
 	local 表示从本地文件系统复制到HDFS文件系统上，后面'/root/hivedata/students.txt'是本地文件路径
 	into table 表示上传在某个数据表下，这里数据表前记得加上所属数据库 itcast.student_local
 
 # 也可以使用 hadoop命令上传，但是官方更加推荐使用 local
 #下面是hadoop fs -put上传方式
hadoop fs -put students.txt  /user/hive/warehouse/itcast.db/student_local
```

![image-20241029163103061](./Hadoop图/image-20241029163103061.png)

4，数据展示，映射成功

![image-20241029163625444](./Hadoop图/image-20241029163625444.png)



###### 案例：HDFS文件系统上传

1，把所需要数据在HDFS分布式文件管理系统上传

![image-20241029164706344](./Hadoop图/image-20241029164706344.png)

2，使用`Hive`官方提供的文件上传方式

```shell
load data inpath '/students.txt' into table itcast.student_hdfs;
	这里已经没有了local，表示不在是本地以复制形式上传
	而是直接从HDFS文件系统 移动到 itcast.student_hdfs 数据表上去
```

![image-20241029164858256](./Hadoop图/image-20241029164858256.png)

3，数据展示，映射成功

这里查看HDFS分布式文件系统目录下已经没有了 students.txt文件

![image-20241029165135387](./Hadoop图/image-20241029165135387.png)

查看 student_hdfs,会发现映射成功

![image-20241029165314952](./Hadoop图/image-20241029165314952.png)



###### 7,Hive官方内置函数

https://cwiki.apache.org/confluence/display/Hive/LanguageManual+UDF
