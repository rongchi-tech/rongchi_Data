##### 1.uname查看操作系统系统信息

​    参数 -a ，可选项代表all，表示获取全部系统信息(类型，全部主机名，内核版本，发布时间，开源计划)

![image-20240706160457104](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706160457104.png)

##### 2.列出当前工作路径下的文件名称

![image-20240706160820315](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706160820315.png)

##### 3.whoami命令 显示当前用户  含义：获取当前用户的用户名

![image-20240706163150968](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706163150968.png)

##### 4.reboot命令 重启操作系统

![image-20240706163253502](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706163253502.png)

##### 5.shutdown命令 关闭操作系统

![image-20240706163515037](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706163515037.png)

​      shutdown   -r  60     含义：延迟重启60分钟之后

​      shutdown   -r  now   含义：立刻重启

##### 6. halt命令  代表立刻关机

halt命令是扩展命令，相当于shutdown  -h  0  代表立刻关机



##### 7. history命令 查看历史命令  作用：列出最近输入的一千条Shell命令信息

![image-20240706164354244](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706164354244.png)

##### 8.hostnamectl主机名命令

![image-20240706165401545](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706165401545.png)

命令：hostnamectl    作用：操作服务器的主机名(读取，设置)

![image-20240706165803525](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240706165803525.png)

###### 8.1 同时设置静态和瞬时主机名

```
用法：输入 hostnamectl set-hostname ["主机名"]
含义：修改当前主机名
```

###### 8.2 分别配置静态，瞬时，灵活主机名

```
用法：输入 hostnamectl --pretty set hostname [”主机名"]
```

##### 9. tar包压缩与解压缩

```
命令： tar
作用： tar选项 打包文件名
参数： [可选项]
-c，create创建的意思
-v，显示打包文件过程
-f，指定打包的文件名，此参数是必须加的
-u，update缩写，更新原打包文件中的文件
-t，查看打包的文件内容
注意：在使用tar命令指定选项时可以不在选项前面输入"-",  cvf 和 "-cvf"起到作用一样
使用tar命令归档的包通常称为tar包,tar包文件都是以".tar"结尾

```

###### 9.1 压缩

```
用法一：
语法：tar [-f 可选项] 文件名.tar 文件/文件夹1 文件/文件夹2 ...
例子：tar cvf test.tar test.txt test
```

![image-20240707151708625](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240707151708625.png)

```
用法二：将文件/文件夹 追加 至压缩包
语法：tar [-uf 可选项] 文件名.tar 待追加文件/文件夹
例子：tar -uf test.tar d.txt
```

![image-20240707153011566](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240707153011566.png)

```
用法三：查看tar包中的内容
语法 tar [-tf 可选项] 文件名.tar
例子：tar -tf test.tar
```

![image-20240707153342608](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240707153342608.png)

###### 9.2 解压

解压tar包时，把可选项命令中的c改为x即可

解压tar包用xcf，解压gzip包用zxvf

```
用法一： tar -xvf
语法：tar -xvf 文件名.tar
例子：tar -xvf test.tar
```

![image-20240707160013343](C:\Users\27252\AppData\Roaming\Typora\typora-user-images\image-20240707160013343.png)

##### 10. tail 查看文件信息(推荐)

```
用法：tail -n 20 test.txt
查看test.txt末尾20行文件信息
```

