###### `iptables`防火墙

容器：存放东西

表(table)：存放链的容器，防火墙最大概念

链(chain)：存放规则的容器

规则(policy)：准许活拒绝规则，未来书写的防火墙条件就是防火墙规则

###### `iptables`执行流程

1，防火墙是**层层过滤**，实际是按照配置的**顺序从上到下**，从前到后进行过滤的。

2，如果匹配成功规则，即明确表示是<u>**拒绝(drop)还是(accept)**,**数据包就不再向下匹配新的规则**。

3，如果规则中没有明确表明是阻止还是通过的，也就是没有匹配规则，向下进行匹配，直到**匹配默认规则**得到明确的阻止还是通过。

4，防火墙的**默认规则是所有规则都匹配完才会匹配的**。

![image-20241220105249157](./iptables图/image-20241220105249157.png)

如果配置了一条拒绝规则，应放在防火墙规则的最上面。



##### 表与链：`iptables`是4表伍链

4表：**filter表 nat表** raw表 mangle表

```
filter表： 表示防火墙功能，屏蔽端口和IP。filter表示过滤器
nat表：实现共享上网，端口映射
```

伍链：**INPUT**  OUTPUT  FORWARD  PREROUTING  POSTROUTING

在防火墙中大写表示链的名字

```
INPUT	进入数据经过
OUTPUT	出去数据经过
FORWARD  路过
PREROUTING  在...之前
POSTROUTING 在...之后
```

###### 每个表说明

`filter表：实现防火墙功能：屏蔽或准许端口IP`

filter表：强调：主要和主机自身相关，真正负责主机防火墙功能的(过滤流入流出主机的数据包)。filter表示iptables默认使用的表，这个表定义了三个链(chain)。工作场景:主机防火墙

INPUT   负责过滤所有目标地址是本地地址的数据包，**就是过滤进入主机的数据包(能否让数据包进入服务器)**

FORWARD 路过,**负责转发流经主机的数据包，起到转发作用。**和NAT关系很大

OUTPUT  处理所有源地址是本机地址的数据包，**就是处理从主机发出去的数据包**



`nat表：实现nat功能：实现共享上网(内网服务器上外网),端口映射和ip映射` 

net表：负责网络地址转换的，即来源与目的IP地址和port的转换。

​      应用：和主机本身无关，一般用于局域网共享上网或者特殊的端口转换

​      工作场景：

​	1，用于企业路由(zebra)或者网关(iptables)，共享上网(POSTROUTING)

​	2, 做内部外部ip地址一对一映射(dmz)，硬件防火墙映射ip到内部服务器，ftp服务(PREROUTING)

​	3，WEB，单个端口的映射，直接映射80端口(PREROUTING) 这个表定义了3个链,nat功能相当于网络的cal控制，和网络交换机acl类似。



OUTPUT     ：和主机放出去的数据包有关，改变主机发出数据包的目的地址。



PREROUTING  ：**在数据包到达防火墙时，进行路由判断之前执行的规则，作用是改变数据包的目的地址、目的端口等**

​	     就是收信时，根据规则重写收件人的地址。

​	     例如:把公网P:xxxoxxxx映射到局域网的xxx服务器上。如果是web服务，可以报80转换为局域网的服务器9000端口上

​	     10.0.0.618080(日标端口)----nat---à10.0.0.7 22



POSTROUTING  ：**在数据包离开防火墙时进行路由判断之后执行的规则，作用改变数据包的源地址，源端口等。**

​	      写好发件人的地址，要让家人回信时能够有地址可回。

​	      例如。默认笔记本和虚拟机都是局域网地址，在出网的时候被路由器将源地址改为了公网地址。生产应用:局域网共享上网。



##### 安装`iptables` 和命令

```shell
# 安装命令管理工具
yum install -y iptables-service

# 查看软件包类容
rpm -ql iptables-services
		/etc/sysconfig/iptables  存放防火墙规则文件
		
# 防火墙相关模块，加载到内核中
# 写入到开机自启动
[root@test3 ~]# cat >>/etc/rc.local <<EOF
modprobe ip_tables
modprobe iptable_filter
modprobe iptable_net
modprobe ip_conntrack
modprobe ip_commtrack_ftp
modprobe ip_nat_ftp
modprobe ipt_state
> EOF
[root@test3 ~]# 
# 永久
modprobe ip_tables
modprobe iptable_filte
modprobe iptable_net
modprobe ip_conntrack
modprobe ip_commtrack_ftp
modprobe ip_nat_ftp
modprobe ipt_state
# 查看
lsmod |egrep 'filter|nat|ipt'
```

###### 查看当前防火墙规则

```shell
iptables -nL  默认查看链(chain)

# 查看别的表 -t 表名
iptables -t filter -nL		指定查看filter表
# 列出当前的防火墙规则
iptables -nL --line-numbers
```

###### `iptables`命令参数

```
-L 	显示表中所有规则
-n	不要把端口或ip反向解析为名字

指定表
-t 指定表  不指定默认filter表

指定连接(加入/追加/删除)
-A INPUT	append追加，加入准许类规则 使用-A
-I INPUT	insert把规则加在链的第1条 拒绝类规则放在所有规则最上面 拒绝类 -I
-D INPUT	delete删除 —D INPUT 1 (这里1是规则编号)
```

```
-p 		协议protocal tcp/udp/icmp/all
-dport	目标端口 dest destination 指定端口加上协议 -p tcp
-sport	源端口  source源
-s		-source源ip
-d		-destination 目标ip
-m		指定模块 multiport
-i		input输入的时候从那个网卡进来
-o		output输出的时候从那个网卡出去
```

```
-j		满足条件后的动作 DROP/ACCEPT/REJECT
				-j DROP：选项用于指定一个动作，DROP 表示丢弃匹配该规则的数据包。
				-j ACCEPT：接受数据包，允许数据包通过防火墙。
				-j REJECT：拒绝，返回拒绝信息
```

| `DROP`   | 丢弃数据包，不响应；不通知源主机。 | `iptables -A INPUT -s 192.168.88.102 -j DROP`   |
| -------- | ---------------------------------- | ----------------------------------------------- |
| `ACCEPT` | 接受数据包，允许数据包通过防火墙。 | `iptables -A INPUT -s 192.168.88.103 -j ACCEPT` |
| `REJECT` | 拒绝数据包，发送拒绝消息给源主机。 | `iptables -A INPUT -s 192.168.88.104 -j REJECT` |

```shell
iptables -F		清除所有规则，不会处理默认规则
iptables -X		删除用户自定义的链(dockerd多用)
iptables -Z		链的计数器清零(数据包计数器与数据包字节计数器)
```



###### 源IP和目标IP

站在防火墙角度，一般屏蔽的都是源IP

源IP：是发起 ping 请求的机器的 IP 地址，通常是你运行 `ping` 命令的机器。

目标IP：是 `ping` 命令中指定的 IP 地址，即你希望进行网络连接的机器的 IP 地址。



###### 案例：屏蔽IP，封IP

在`192.168.88.103`机器上屏蔽`192.168.88.102`

```shell
# -t没有指定表，默认filter表，丢弃所有来自原ip（-s表示原IP）192.168.88.102进入（-I INPUT表示进入到）192.168.88.103的数据包
iptables -I INPUT -s 192.168.88.102 -j DROP
```

![image-20250102110515605](./iptables图/image-20250102110515605.png)

```shell
Chain INPUT (policy ACCEPT)
target     prot opt source               destination         
DROP       all  --  192.168.88.102       0.0.0.0/0

# iptables -nL规则分析
Chain INPUT：表示这是查看 INPUT 链的规则，INPUT 链处理所有进入本机的流量。

target：
DROP：这是匹配到该规则时采取的动作，表示丢弃数据包。也就是说，任何来自指定 IP 地址（192.168.88.102）的流量都会被丢弃，不允许它进入系统。

prot：
all：表示此规则适用于所有协议的流量（例如 TCP、UDP、ICMP 等）。没有指定特定的协议，意味着该规则适用于所有传入的协议。

opt：
--：表示没有特定的选项，空值。

source：
192.168.88.102：表示此规则仅适用于源 IP 地址为 192.168.88.102 的流量。

destination：
0.0.0.0/0：表示此规则适用于所有目标 IP 地址。0.0.0.0/0 是一个通配符，表示匹配所有 IP 地址。
```



###### 案例：删除防火墙规则

```shell
# 1，先查看防火墙规则，并确定要删除的规则
# --line-numbers是显示行号
iptables -nL --line-numbers

# iptables + -D(delete的意思) + INPUT(进入本机的规则) + 1(规则编号，默认在tptables规则最上面)
iptables -D INPUT 1

# 清空 所有的防火墙规则
iptables -F

# 想清空某个特定链中的规则，可以指定链名。清空 INPUT 链中的规则
iptables -F INPUT
```

![image-20250102112906880](./iptables图/image-20250102112906880.png)

![image-20250102113249171](./iptables图/image-20250102113249171.png)

###### 案例：屏蔽整个网段和端口

屏蔽整个网段，如果网段包含了本机IP。会使ssh登陆失效

```shell
# 192.168.88.102/24 表示屏蔽了整个192.0.0.0(0,1~254,255 网路，hosts，广播)
iptables -I INPUT -s 192.168.88.102/24 -j DROP  //简约写法：iptables -I INPUT -s 192.0.0.0/24 -j DROP 

# 屏蔽了整个192.168.88.0(0,1~254,255 网路，hosts，广播)
iptables -I INPUT -s 192.168.88.0/8 -j DROP
```

禁止192.0.0.0/24网段访问8888端口

```shell
# -t filter(-t表示指定表，默认filter。-p tcp指定tcp协议。--dport 8848指定端口)
iptables -t filter -I INPUT -s 192.0.0.0/24 -p tcp --dport 8848 -j DROP

-t filter 指定表
-I INPUT  插入在规则第一条
-s 192.0.0.0/24  指定源IP网段
-p tcp	指定tcp协议
--dport 8848  指定端口
-j DROP  删除包，不通知源主机
```



###### 只允许指定网段连入

允许172.0.0.0/24网段连入，其他全部禁止

实现白名单功能 默认是拒绝 开放端口 网段

```shell
# 方法1：利用 ! 进行排除，表示除了172.0.0.1网段可以访问外，其他的网段IP都会被拒绝
iptables -I INPUT ! -s 172.0.0.0/24 -j DROP


# 拒绝来自172.0.0.12源IP访问
iptables -I INPUT -s 172.0.0.12 -j DROP
# 指定源IP前面加上 ！ 表示只允许172.0.0.12访问
iptables -I INPUT ! -s 172.0.0.12 -j DROP
```



###### `-m multipor`指定多个端口

指定了3个端口`-m multiport -p tcp --dport 80,443,8848`

```shell
# 指定多个端口并拒绝的规则
iptables -I INPUT -m multiport -p tcp --dport 80,443,8848 -j DROP

# 把 30000~32000之间的所有端口全部屏蔽
# 30000:32000 表示范围
iptables -I INPUT -m multiport -p tcp --dport 30000:32000  -j DROP
```

![image-20250120164507678](./iptables图/image-20250120164507678.png)



###### 案例：匹配`ICMP`类型，禁止`ping`

`ICMP`，Internet控制报文协议ping

整个网站核心,用于不想让外界检查某个服务器在不在

**1,通过防火墙规则，控制是否可以ping**

```shell
# --icmp-type 8
# 此时整个防火墙不可ping
iptables -I INPUT -p icmp --icmp-type 8 -j DROP //缩写如：iptables -I INPUT -p icmp -j DROP
```

![image-20250208143634447](./iptables图/image-20250208143634447.png)



**2，通过修改内核参数 控制 禁止被ping**此方法用于防火墙关闭的机器

所有的Linux内核参数都是在 `/proc/sys/`目录下

![image-20250208145247462](./iptables图/image-20250208145247462.png)

```shell
永久生效，重启系统不会丢失
[root@test3 ~]# vim /etc/sysctl.conf
net.ipv4.icmp_echo_ignore_all = 1 		 # 禁止被ping
[root@test3 ~]# sysctl -p				# 永久生效，重启系统不会丢失


临时生效 重启会丢失
在linux内核参数目录下 /proc/sys/ 修改 icmp_echo_ignore_all 文件 0为1 
icmp_echo_ignore_all=1 会导致同网段为添加次参数的主机ping不通

[root@test3 ~]# ll -d /proc/sys/net/ipv4/icmp_echo_ignore_all
-rw-r--r--. 1 root root 0 2月   8 14:57 /proc/sys/net/ipv4/icmp_echo_ignore_all
[root@test3 ~]# cat /proc/sys/net/ipv4/icmp_echo_ignore_all
0
[root@test3 ~]# echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all
```

![image-20250208150044797](./iptables图/image-20250208150044797.png)



###### 匹配网络状态(TCP/UDP连接状态，TCP三次握手四次挥手)

```
TCP 三次握手（建立连接）：
目的：客户端和服务器在通信前，需要建立一个可靠的连接，确保双方能够正确发送和接收数据。
1.第一次握手（SYN）：客户端向服务器发送一个 SYN（synchronize）包，表示要建立连接，并附带一个初始序列号 seq = x。
2.第二次握手（SYN-ACK）：服务器收到 SYN 后，回复一个 SYN-ACK 包，表示同意建立连接，并附带自己的初始序列号 seq = y，同时对客户端的 SYN 进行确认（ack = x + 1）。
3.第三次握手（ACK）：客户端收到 SYN-ACK 后，发送一个 ACK 包（ack = y + 1）给服务器，表示确认服务器的 SYN，连接正式建立。

TCP 四次挥手（断开连接）：
目的：TCP 连接是全双工的，因此断开连接时需要双方都同意断开，并确保所有数据已经传输完毕。
1.第一次挥手（FIN）：客户端向服务器发送 FIN（Finish）包，表示自己不再发送数据了，但仍可以接收数据。
2.第二次挥手（ACK）：服务器收到 FIN 后，返回一个 ACK（ack = seq + 1），表示已经收到客户端的断开请求，但还需要处理未发送完的数据。
3.第三次挥手（FIN）：服务器处理完剩余数据后，发送 FIN 包给客户端，表示自己也要断开连接。
4.第四次挥手（ACK）：客户端收到 FIN 后，回复 ACK，然后进入 TIME_WAIT 状态，等待一段时间（默认 2 * MSL，最大报文存活时间），确保服务器收到了 ACK 后才真正关闭连接。
服务器收到最后的 ACK 后，连接正式断开。
```

防火墙去控制连接状态`-m state --state`

NEW 已经或将启动新的连接

**ESTABLISHED 已建立的连接**

**RELATED 正在启动的新连接**

INVALID 非法或无法识别的

```shell
# 允许进入的数据
iptables -A INPUT -m state --state ESTABLISHED RELATED -j ACCEPT
# 允许出去的数据
iptables -A OUTPUT -m state --state ESTABLISHED RELATED -j ACCEPT
```



###### 限制并发及速率

一般用nginx实现，也可以用iptables实现(用户请求就不用到达nginx了，在防火墙着就被挡住)

`-m limit`限制模块

```shell
-m limit --limit 10/minute    #每分钟只能有10个数据包 每6秒生成
```

ping icmp协议 进行测试

```shell
# 在第一条规则位置插入：每分钟只能有10个数据包 每6秒生成一个,突发情况下最多允许 5 次请求。
iptables -I INPUT  -p icmp  -m limit --limit 10/minute  --limit-burst 5 -j ACCEPT

# 在第一条规则后追加一条规则：允许通过 TCP 协议连接到本机的 22 端口（通常用于 SSH 连接）。
iptables -A INPUT -p tcp --dport 22 -j ACCEPT

# 设置防火墙的默认策略为丢弃所有进入本机的网络流量
iptables -P INPUT DROP  默认规则一定放在最后
```



###### 防火墙规则的保存与恢复

1.保存当前规则

```shell
# iptables规则打印在屏幕上
iptables-save  

# iptables规则重定向（保存）到 /etc/sysconfig/iptables 中
iptables-save >/etc/sysconfig/iptables
```

2.恢复默认规则

```shell
iptables-restore </etc/sysconfig/iptables
```



##### filter表生产实际用法

防火墙配置方式: `iptables -P INPUT DROP`默认规则改为 DROP 白名单模式(配置规则允许了才能进来)

流程：

- ssh
- 服务
- 连接状态
- 数据包进出
- 转发
- 修改默认规则为DROP 



1，`ssh`可以连接 目的：确保22端口可以连接

`iptables -A INPUT -p tcp --dport 22 -j ACCEPT`追加条允许tcp协议的22端口进入防火墙

```shell
[root@test3 ~]# iptables -F			// 情况链中所有规则
[root@test3 ~]# iptables -X			// 删除自定义的链
[root@test3 ~]# iptables -Z			// 重置链计数器和数据包计数器为零
[root@test3 ~]# iptables -nL
Chain INPUT (policy ACCEPT)
target     prot opt source               destination         

Chain FORWARD (policy ACCEPT)
target     prot opt source               destination         

Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination         
[root@test3 ~]# iptables -A INPUT -p tcp --dport 22 -j ACCEPT
[root@test3 ~]# iptables -nL
Chain INPUT (policy ACCEPT)
target     prot opt source               destination         
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:22

Chain FORWARD (policy ACCEPT)
target     prot opt source               destination         

Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination  
```



2，设置允许本机lo(lo表示回环网卡)

允许本机回环 lo 接口数据流量输入与输出

```shell
[root@test3 ~]# iptables -A INPUT -i lo -j ACCEPT
[root@test3 ~]# iptables -A OUTPUT -o lo -j ACCEPT
```



3，配置默认规则及放行端口(80,443)

`iptables -A INPUT -m multiport -p tcp --dport 443,80 -j ACCEPT`追加条(80,443)端口允许进入的规则

```shell
[root@test3 ~]# iptables -P INPUT DROP		// 默认规则改为拒绝所有输入的流量
[root@test3 ~]# iptables -P FORWARD DROP	// 默认规则改为拒绝所有转发的流量
[root@test3 ~]# iptables -P OUTPUT ACCEPT	// 默认规则改为允许所有输出的流量
[root@test3 ~]# 
[root@test3 ~]# iptables -A INPUT -m multiport -p tcp --dport 443,80 -j ACCEPT
[root@test3 ~]# iptables -nL
Chain INPUT (policy DROP)
target     prot opt source               destination         
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:22
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            multiport dports 443,80

Chain FORWARD (policy DROP)
target     prot opt source               destination         

Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination         
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0  
```



4，配置允许访问的网段(192.168.88.0/8,10.0.0.0/24),和一个vpn网段(172.16.1.0/24)

```shell
[root@test3 ~]# iptables -A INPUT -s 192.168.88.0/24 -j ACCEPT
[root@test3 ~]# iptables -A INPUT -s 10.0.0.0/24 -j ACCEPT
[root@test3 ~]# iptables -A INPUT -s 172.16.1.0/24 -j ACCEPT
[root@test3 ~]# iptables -nL
Chain INPUT (policy DROP)
target     prot opt source               destination         
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:22
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            multiport dports 443,80
ACCEPT     all  --  192.168.88.0/24      0.0.0.0/0           
ACCEPT     all  --  10.0.0.0/24          0.0.0.0/0           
ACCEPT     all  --  172.16.1.0/24        0.0.0.0/0           

Chain FORWARD (policy DROP)
target     prot opt source               destination         

Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination         
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0     
```



5,配置连接状态

```shell
[root@test3 ~]# iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
[root@test3 ~]# iptables -A OUTPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
[root@test3 ~]# iptables -nL
Chain INPUT (policy DROP)
target     prot opt source               destination         
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:22
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            multiport dports 443,80
ACCEPT     all  --  192.168.88.0/24      0.0.0.0/0           
ACCEPT     all  --  10.0.0.0/24          0.0.0.0/0           
ACCEPT     all  --  172.16.1.0/24        0.0.0.0/0           
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0            state RELATED,ESTABLISHED

Chain FORWARD (policy DROP)
target     prot opt source               destination         

Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination         
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0            state RELATED,ESTABLISHED
```



6，修改filter表默认规则为DROP  (在步骤3已完成)

```shell
[root@test3 ~]# iptables -P INPUT DROP		// 默认规则改为拒绝所有输入的流量
[root@test3 ~]# iptables -P FORWARD DROP	// 默认规则改为拒绝所有转发的流量
[root@test3 ~]# iptables -P OUTPUT ACCEPT	// 默认规则改为允许所有输出的流量
```



##### nat表实现共享上网(重要)

```shell
[root@test3 ~]# cat /etc/sysctl.conf 
# sysctl settings are defined through files in
# /usr/lib/sysctl.d/, /run/sysctl.d/, and /etc/sysctl.d/.
#
# Vendors settings live in /usr/lib/sysctl.d/.
# To override a whole file, create a new file with the same in
# /etc/sysctl.d/ and put new settings there. To override
# only specific settings, add a file with a lexically later
# name in /etc/sysctl.d/ and put new settings there.
#
# For more information, see sysctl.conf(5) and sysctl.d(5).

net.ipv4.ip_forward = 1		# 内核转发：用于共享上网
net.ipv4.icmp_echo_ignore_all = 1 #icmp协议:用于禁ping
```

流程：内网机器去上外网。只要是某一个网段(如172.16.0.0/16)进来的，防火墙就会把该网段伪装成一个指定公网IP网段(10.0.0.16/24)

https://www.bilibili.com/video/BV1tN411m7dE/?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=9



##### nat表实现端口转发(docker重要)

用户访问一台内网，需要端口映射;用户只要访问防火墙的9000端口，就会被转发到172.16.1.7的22端口

![image-20250210144755551](./iptables图/image-20250210144755551.png)



```shell
[root@test3 ~]# iptables -t nat -A PREROUTING -d 10.0.0.61 -p tcp --dport 9000 -j DNAT --to-destination 172.16.1.7:22
将目标 IP 地址为 10.0.0.61 且目标端口为 9000 的 TCP 流量重定向到目标 IP 地址为 172.16.1.7，端口为 22 的服务器上。
-t nat -A PREROUTING	指定nat表，指定PREROUTING链
-d 10.0.0.61 -p tcp --dport 9000	目标IP和目标端口
-j DNAT 目标地址转换
--to-destination 172.16.1.7:22	用户访问目标IP和端口(10.0.0.61:9000)就会改成指定的IP和端口(172.16.1.7:22)


[root@test3 ~]# iptables -t nat -nL
Chain PREROUTING (policy ACCEPT)
target     prot opt source               destination         
DNAT       tcp  --  0.0.0.0/0            10.0.0.0/8           tcp dpt:9000 to:172.16.17.0:22
```



 案例：将目标 IP 地址为 `192.168.88.103`，且目标端口为 `9000` 的 TCP 流量转发到同一台机器上的端口 `22`（通常是 SSH 服务的端口）。

```shell
[root@test3 ~]# iptables -t nat -A PREROUTING -d 192.168.88.103 -p tcp --dport 9000 -j DNAT --to-destination 192.168.88.103:22
[root@test3 ~]# iptables -t nat -nL --line-numbers
Chain PREROUTING (policy ACCEPT)
num  target     prot opt source               destination         
1    DNAT       tcp  --  0.0.0.0/0            192.168.88.103       tcp dpt:9000 to:192.168.88.103:22 
```

![image-20250210154524230](./iptables图/image-20250210154524230.png)
