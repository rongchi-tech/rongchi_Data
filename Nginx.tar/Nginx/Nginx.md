##### CentOS8安装nginx

0，环境准备 https://www.bilibili.com/video/BV1ov41187bq?spm_id_from=333.788.videopod.episodes&vd_source=da0ca5a74459b110b3a6da903d245e14&p=7

1，依赖下载

```
yum install -y gcc-c++ pcre pcre-devel zlib zlib-devel openssl openssl-devel
yum install -y make
```

2，访问官网，下载nginx。传入linux系统

参考文献：https://blog.csdn.net/qq_65732918/article/details/131862373

3，解压

```
tar -zxvf nginx-1.26.2.tar.gz
```

4，进入解压后文件`nginx-1.26.2`

```
cd nginx-1.26.2/
```

5，运行`./configure`并安装在指定目录下`--prefix=/usr/local/nginx`

```
./configure --prefix=/usr/local/nginx
```

6，编译

```
make&&make install
```

7，进入安装目录，会发现nginx目录

```
cd /usr/local
```

![image-20240910162241962](C:/Users/27252/Desktop/%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87/%E5%B8%B8%E7%94%A8%E5%A4%B9/Nginx/Nginx%E5%9B%BE/image-20240910162241962.png)

8，进入`nginx/sbin/`目录，会发现nginx可执行文件

```
cd nginx/sbin/
```

![image-20240910162534717](C:/Users/27252/Desktop/%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87/%E5%B8%B8%E7%94%A8%E5%A4%B9/Nginx/Nginx%E5%9B%BE/image-20240910162534717.png)

9，启动nginx服务

```
./nginx
```

服务启动成功，在浏览器输入nginx服务IP会出现如下内容

服务启动成功，浏览器内容加载失败。关闭防火墙

参考文献https://www.bilibili.com/video/BV1yS4y1N76R?p=7&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14

![image-20240910162627039](C:/Users/27252/Desktop/%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87/%E5%B8%B8%E7%94%A8%E5%A4%B9/Nginx/Nginx%E5%9B%BE/image-20240910162627039.png)

##### nginx启停命令(重要)

1，进入安装好的目录`cd /usr/local/nginx/sbin/`

```shell
./nginx		启动
./nginx	-s stop		快速停止
./nginx -s quit		优雅关闭，在退出前完成已经接受的链接请求
./nginx -s reload	重新加载配置文件

如果启动了nginx,但发现无法打开nginx网页,尝试关闭防火墙
systemctl stop firewalld.service

禁止防火墙开机启动
systemctl disable firewalld.service

放行端口
firewall-cmd --zone=public --add-port=80/tcp --permanent

开机自启动
systemctl enable nginx.service
```

2，HUP对更新nginx配置文件非常有效

```
HUP	重新配置文件并使用服务对新配置生效
kill -HUP [worker对应的master进程号]
```

![image-20241209104530445](./Nginx图/image-20241209104530445.png)



3，USR2：nginx升级版本，在不关闭服务情况下，进行平滑升级

USR2解析视频

https://www.bilibili.com/video/BV1ov41187bq?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=17

案例，平滑升级版本视频

https://www.bilibili.com/video/BV1ov41187bq?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=20

案例，make升级版本视频

https://www.bilibili.com/video/BV1ov41187bq?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=21



4， nginx命令行服务

![image-20241209111237442](./Nginx图/image-20241209111237442.png)

![image-20241209112103068](./Nginx图/image-20241209112103068.png)

```
-v -V 都是显示版本信息
-t -T 显示测试成功信息，-t只显示成功信息，-T会多显示测试成功的文件 

# 常用
./nginx -s reload 重新加载配置文件
```



5，在根目录下创建软连接,避免每次切换目录启动

```
ln -s /usr/local/nginx/sbin/nginx /nginx_on
```

![image-20240910164455219](C:/Users/27252/Desktop/%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87/%E5%B8%B8%E7%94%A8%E5%A4%B9/Nginx/Nginx%E5%9B%BE/image-20240910164455219.png)

```
# 启动服务
./nginx_on
```



##### nginx目录结构与运行原理

- 目录结构


文件夹后缀带有`_temp`都是在运行nginx服务后产生的，原本nginx目录下没有这么多文件夹

![image-20240910165620647](C:/Users/27252/Desktop/%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87/%E5%B8%B8%E7%94%A8%E5%A4%B9/Nginx/Nginx%E5%9B%BE/image-20240910165620647.png)

```
/conf		conf目录下放的是nginx主配置文件nginx.conf，nginx.conf此配置文件会引用其它同级的配置文件
/html		默认情况下存放网页和静态资源  index.html是默认页面
/logs		记录日志:logs目录下有access.log(用户访问日志) error.log(系统出现错误日志) nginx.pid(记录nginx主进程ID号)
/sbin		sbin目录下放的是nginx的主程序
```

- 运行原理

参考文献：https://www.bilibili.com/video/BV1yS4y1N76R?p=9&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14



###### nginx配置文件

包含 全局块，events块，http块

```shell
#user  nobody;
worker_processes  1;		#开启的进程数：1

events {
    worker_connections  1024;	#每1个worker_进程创建的连接数：1024
}

http {
    include       mime.types;	#记录所有的mime.types(请求头:会标明属于什么文件)
    default_type  application/octet-stream;	#默认，如果不在mime.types中，会以application/octet-stream流方式传输给客户端浏览器

    sendfile        on;		#数据零拷贝：不需要复制和拷贝
    keepalive_timeout  65;	#保持连接，超时时间：65


#主机(开启多个主机的方式叫 vhost虚拟主机，一个server代表一个主机)
    server {
        listen       80;		 #默认监听端口号：80  listen监听
        server_name  localhost;	 #配置域名或主机名    server_name服务名称
		
		#域名后面跟的子目录 URL
		#URL== 域名 + 后跟一些资源
		# URL   -->   https://www.bilibili.com/video/BV1yS4y1N76R/
		# URI   -->   video/BV1yS4y1N76R/
		
#location / 用于匹配URI
#一个server主机下面可以有多个location
        location / {
            root   html;	#root目录，相对路径	root资源目录				
            index  index.html index.htm;	#index展示默认网页	index.html index.htm都要放在html目录下才能访问
        }
        error_page   500 502 503 504  /50x.html;	#发生服务器错误时，会跳转当前站点的/50x.html网页上、 error_page后跟错误码
        
        #一但访问 /50x.html时，会跳转至  location = /50x.html 下的root目录并指向html网页
        location = /50x.html {
            root   html;
        }
    }
}
```

全局块参数解析

```
user nobady：用于配置运行Nginx服务器的worker进程的用户和用户组，默认值nobady
master_process on/off: 用来指定是否开启工作进程，默认on
daemon on/off：设定Nginx是否以守护进程的方式启动，默认on
pid File: 用来配置Nginx当前master进程的进程号ID存储的文件路径，默认位置/usr/local/nginx/logs/nginx.pid

error_log File [日志级别]: 用来配置Nginx的错误日志存放路径，默认值error_log logs/error.log error;
  error_log File 在nginx.conf的全局块，http，server，location
  其中[日志级别]的值有:debuglinfo|notice|warn|error|crit|alert|emerg

include: 用来引入其他配置文件，使Nginx的配置更加灵活
  include在nginx.conf的任何位置
```

守护式进程：是linux后台执行的一种服务进程，特点是独立与控制终端，不会随着终端关闭而停止。(守护进程会独立占用一个终端)



events块参数解析

```
events {
    accept_mutex on;			用来设置nginx网络连接序列化 ，默认on。用于解决“惊群”问题
    multi_accept on;			用来设置是否允许同时接收多个网络连接，默认off。如果为off表示一个进程只能接受一个连接
    worker_connections  1024;	用来设置单个进程最大连接数
    use epoll;				   用来设置nginx服务器选择哪种事件驱动来处理网络消息 可选值select/poll/epoll/kqueue I/O多路复用的不同实现方式
}
```

惊群：指的是所有进程同时被唤醒去抢一个请求，直观体现是浪费进程资源。accept_nutex为on时。使得进程一个一个被唤醒，防止多进程抢占请求。



http块

```
定义MIME-Type,Nginx配置文件中默认两行配置
  include mime-types;						    include用来把mime-types包含在nginx.conf文件里面
  default_type application/octet-stream;		用来配置Nginx响应前端请求默认的MIME类型
  	默认值: default_type text/plain;
  	位置: http,events,location
  	
自定义服务日志
  Nginx中日志类型分access.log, error.log
  access.log: 用来记录用户所有的访问请求。用来设置访问日志的相关属性
  error.log：记录nginx本身运行时的错误信息，不会记录用户的访问请求
  log_format：用来指定日志的输出格式
  
 sendfile on/off: 用来设置Nginx服务器是否使用sendfile()传输文件,该属性可以提高Nginx处理静态资源的性能
   默认 off
   位置 http,server,location
  
 keepalive_timeout 75s ：用来设置长连接的超时时间，默认75s
   位置 http,server,location
 
 keepalive_requests 100 ：用来设置一个keep-alive的连接次数，默认100次
   位置 http,server,location
```

长连接：通过HTTP协议(底层连接请求就是TCP)，发送TCP连接请求(3次握手4次挥手,请求结束后会断开)。请求结束后不断开，等下次请求过来时直接复用之前的请求。

server块

```
一个nginx.conf里面可以放多个server块
```

location块

```
一个server块里面可以放多个location块
```



##### 静态资源部署

###### 1，静态资源配置指令

```
listen指令：用来配置监听端口	listen address	listen port
  listen 127.0.0.1:8000; 	listen localhost:8000 监听指定的ip和端口
  listen 127.0.0.1			监听指定IP的所有端口
  listen 8000;				监听指定端口上的连接
  listen *:8000;			监听指定端口上的连接
```



##### 虚拟主机与域名

![image-20240912112611465](C:/Users/27252/Desktop/%E6%A1%8C%E9%9D%A2%E5%9B%BE%E6%A0%87/%E5%B8%B8%E7%94%A8%E5%A4%B9/Nginx/Nginx%E5%9B%BE/image-20240912112611465.png)

###### 2,本地host文件配置域名解析 与 真正域名解析

真正域名解析：https://www.bilibili.com/video/BV1yS4y1N76R?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=15

本地host文件配置域名解析：

环境:win11,虚拟机linux,启动了nginx服务

1,编辑本机hosts文件，添加linux机器IP及域名(域名随便取)

![image-20250211155037536](./Nginx图/image-20250211155037536.png)



2，ping域名，其实就是ping本机

![image-20250211155209158](./Nginx图/image-20250211155209158.png)

3，浏览器输入 rc.com 会出现nginx页面

![image-20250211155314999](./Nginx图/image-20250211155314999.png)



###### 1，浏览器，nginx与http协议

电脑从dns拿到了ip地址，会发起tcp/ip协议请求。因为http协议(http高级网络协议)在tcp/ip(tcp/ip基础网络协议)协议之上，tcp/ip基础网络协议能包容一切上层网络协议。

https协议是在http协议保证正常访问情况下，额外增加了一层数据安全保障



###### 2，虚拟主机原理

多个域名对应在一个ip地址上，由nginx服务器端来判断访问哪个域名。

比如两个不同域名同时指向一个ip地址，请求ip地址时候，在请求协议上带上域名头。nginx解析到域名，去对应的域名目录下找资源即可

参考文献：https://www.bilibili.com/video/BV1yS4y1N76R/?p=12&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14



###### 3，虚拟主机`servername`匹配机制

原本一台服务器只能对应一个站点，通过虚拟主机技术可以虚拟化成多个站点同时对外提供服务

`servername`匹配机制：匹配分先后顺序，前面匹配成功就不会继续往下匹配了

- 完全匹配

   在同一`servername`中匹配多个域名

```
server_name  vod.mmban.com  www1.mmban.com;
```

- 通配符匹配

```
server_name *.mmban.com
```

- 通配符结束匹配

```
server_name vod.*;
```

- 正则匹配

```
server_name ~^[0-9]+\.mmban\.com$;
```



##### 反向代理

反向代理流程图：隧道式代理

![image-20240924142740924](./Nginx%E5%9B%BE/image-20240924142740924.png)

###### 反向代理，网关，正向代理

反向代理：

   用户通过互联网访问系统时。进入内网的网关路由，路由会把用户请求转发到服务器上。但是现在服务器是`nginx服务器`,它作为反向代理服务器，需要把用户所有请求转发到后端应用服务器。

   反向代理则是服务器端的中介。客户端请求被直接发送到反向代理服务器，然后由反向代理将请求转发给实际的目标服务器。客户端认为自己直接与反向代理服务器进行交互。

   `Internet上的连接请求发送代理服务器， 代理服务器将请求发送到反向代理服务器，由反向代理服务器去选择目标服务器获取数据后，在返回给客户端，此时反向代理服务器和目标服务器对外就是一个服务器,暴露的是代理服务器地址，隐藏真实服务器IP地址`

正向代理：

   正向代理是客户端与目标服务器之间的中介。客户端向代理服务器发送请求，代理服务器再将请求转发到目标服务器。目标服务器只知道请求来自代理，而不知晓实际的客户端。

   `在客户端(浏览器)配置代理服务器，通过代理服务器进行互联网访问`

网关：

   访问网络的入口。代理服务器有时也是网关，比如正向代理时。网关可以配置多个

```
正向代理： 局域网中的电脑用户想要直接访问网络是不可行的，只能通过代理服务器来访
问，这种代理服务就被称为正向代理。正向代理类似一个跳板机，代理访问外部资源。比
如：我是一个用户，我访问不了某网站，但是我能访问一个代理服务器，这个代理服务器，
它能访问那个我不能访问的网站，于是我先连上代理服务器，告诉它我需要那个无法访问
网站的内容，代理服务器去取回来,然后返回给我。正向代理应用最广泛的就是“科学上网
工具”。

反向代理：客户端无法感知代理，因为客户端访问网络不需要配置，以==代理服务器==
来接受 internet 上的连接请求，然后把请求发送到反向代理服务器，由反向代理服务器去
选择目标服务器获取数据，然后再返回到客户端。此时反向代理服务器和目标服务器对外
就是一个服务器，暴露的是代理服务器地址，隐藏了真实服务器 IP 地址。
综上所述：正向代理代理对象是客户端，反向代理代理对象是服务端。
```

![image-20241209161323824](./Nginx图/image-20241209161323824.png)

###### 隧道式代理

这种代理方式，进出都得走一个口。

DR模型-避免隧道式代理：

   用户请求进入内网网关并转发至`nginx服务器`，`nginx服务器`把用户请求在转发给后端应用服务器。后端应用服务器接受请求后，直接把数据转发给用户。不在通过代理服务器，这就是DR模型。



#####  基于反向代理的负载均衡器

`nginx服务器`在进行请求转发时，转发到的后端应用服务器如果出现不可用情况。可以进行故障转移,转移到后端其它可用的应用服务器上，而且这些服务器可同时对外提供服务，这就是代理的负载均衡。需要被负载均衡的服务器称为服务器的集群。

###### 负载均衡

   单个服务器解决不了多个用户请求，我们增加服务器的数量，然后将请求分发到各个服务器上，`将原先请求集中到单个服务器上的情况 改为将请求分发到多个服务器上，将负载分发到不同的服务器。`也就是我们所说的负载均衡

###### 动静分离

为了加快网站的解析速度，可以把动态页面和静态页面由不同的服务器来解析，加快解析速度，降低原来单个服务器的压力

###### 服务器的集群：

   一般指的是需要被负载均衡的服务器，这些服务器的配置和可提供的服务都是一样的。

###### 负载均衡算法-轮询式：

   指的是不同用户请求通过代理服务器，代理服务器把请求转发给后端应用服务器集群。但此时，不在是一个后端应用服务器进行请求处理，而是每一次用户请求转发给不同的后端应用服务器。这就是轮询机制

(轮询机制：理解为皇帝掀牌子，每天睡一个不同的姑娘)

###### retry机制

代理服务器把用户请求已经转发在集群下的某一台后端应用服务器下，发现此服务器无法提供服务。`retry机制`会让此服务器下线，并且转发给集群下另一台服务器。

(retry机制:理解为姑娘不行就赶紧换，不能耽误了晚上的事)

###### 配置反向代理服务器

1，找到`nginx.conf`修改配置文件

![image-20240925104452117](./Nginx%E5%9B%BE/image-20240925104452117.png)

2,`proxy_pass`是在`location /`下使用的

```
# 后接两种形式
proxy_pass 代理地址(主机或者网址)
proxy_pass 配成一组服务器
```

![image-20240925104819410](./Nginx%E5%9B%BE/image-20240925104819410.png)



##### nginx常用命令

使用nginx操作命令前提条件：

​	必须进入nginx的目录下:`cd /usr/local/nginx/sbin/`

```nginx
# 1，查看nginx版本号
./nginx -V

# 2，启动nginx
./nginx

# 3，关闭nginx
./nginx -s stop

# 4，重新加载nginx
./nginx -s reload

# 5,查看nginx端口号
ps -ef | grep nginx
```

1,查看nginx版本号

![image-20240925153203703](./Nginx%E5%9B%BE/image-20240925153203703.png)

2,关闭nginx，启动nginx，查看端口号

![image-20240925153616717](./Nginx%E5%9B%BE/image-20240925153616717.png)

3，重新加载nginx

![image-20240925153950709](./Nginx%E5%9B%BE/image-20240925153950709.png)



###### 案例1:nginx-反向代理

```
建议开启防火墙进行实验
	systemctl start firewalld
查看开放的端口号
	firewall-cmd --list-all
设置开放的端口号
	firewall-cmd --add-port=80/tcp --permanent		# nginx端口
	firewall-cmd --add-port=8080/tcp --permanent	# tomcat端口
重启防火墙
	firewall-cmd --reload
```

实验步骤：

```nginx
1，实现效果
（1），打开浏览器，在浏览器地址栏输入地址 www.123.com ,跳转到linux系统tomcat主页面中

2，准备工作
（1），在linux系统安装tomcat，使用默认端口8080，目录放在 /usr/src
	  tomcat官网下载`tar.gz`文件

（2），安装jdk，这里安装11，验证安装
	sudo dnf install java-11-openjdk-devel
	java --version

（3），解压，进入
	  tar -zxvf apache-tomcat-9.0.95.tar.gz
      cd /apache-tomcat-9.0.95

（4），进入 bin 目录，启动 ./startup.sh 脚本文件
      cd bin
      ./startup.sh

（5），进入 logs 目录，查看日志文件，过滤 
      cd logs/
      tail -f catalina.out

（6），查看端口号建议，IP地址:对应服务端口
      tomcat:  192.168.88.100:8080
	  nginx:   192.168.88.100:80

对外开放访问端口，在防火墙启动的情况下
# 查看已经开放的端口
firewall-cmd-list-all
```

![image-20240926170112338](./Nginx%E5%9B%BE/image-20240926170112338.png)

```
3，访问过程分析
   这里浏览器是不能直接访问tomcat，需要通过nginx反向代理。
   tomcat也只能接受到nginx传过来的ip
```

![image-20240925171622379](./Nginx%E5%9B%BE/image-20240925171622379.png)

```
4，具体配置
（1），在windows系统的host文件进行域名和ip对应关系的配置
      C:\Windows\System32\drivers\etc\hosts
      编辑hosts
      192.168.88.100 www.100.com
      
（2），在nginx进行请求转发的配置（反向代理配置）
      首先找到nginx配置文件
      vim /usr/local/nginx/conf/nginx.conf
      
      在location本地添加
      praxy_pass http://127.0.0.1:8080
```

![image-20240926163127317](./Nginx%E5%9B%BE/image-20240926163127317.png)

当用户访问`www.100.com`时，通过nginx地址路径跳转到`tomcat127.0.0.1:8080`,这就是反向代理

![image-20240926163433487](./Nginx%E5%9B%BE/image-20240926163433487.png)

参考文献：

https://www.bilibili.com/video/BV1zJ411w7SV?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=8

https://www.bilibili.com/video/BV1zJ411w7SV?spm_id_from=333.788.player.switch&vd_source=da0ca5a74459b110b3a6da903d245e14&p=9
