虚拟机自定义网络 `cd /etc/sysconfig/network-scripts/`

https://huaweicloud.csdn.net/6715f45c0636ea24a0c26998.html?dp_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6NTc0Njk1MCwiZXhwIjoxNzM0MDU5NzAwLCJpYXQiOjE3MzM0NTQ5MDAsInVzZXJuYW1lIjoicXFfNjU4MDE2MzIifQ.6n9t_amuVYil9-5QvoXg1227bmaGtkv79qsU7KeC9ic&spm=1001.2101.3001.6650.6&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7EBlogCommendFromBaidu%7Eactivity-6-109506757-blog-118854591.235%5Ev43%5Epc_blog_bottom_relevance_base5&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7EBlogCommendFromBaidu%7Eactivity-6-109506757-blog-118854591.235%5Ev43%5Epc_blog_bottom_relevance_base5&utm_relevant_index=13

##### Linux目录结构

查看网络信息`vim /etc/sysconfig/network-scripts/ifcfg-ens160`

其中 `boot dev lib lib64 proc sys`不要动

![image-20240830110430316](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240830110430316.png)

```shell
/bin 		基本用户命令的可执行文件
/boot		包含启动加载器和内核文件，如 GRUB 引导加载器配置文件和 Linux 内核
/dev		包含设备文件，代表系统中的硬件设备，如硬盘 (/dev/sda)、光驱 (/dev/cdrom)
/etc		软件的环境变量，包含系统配置文件和脚本
/home		存放用户的主目录，每个用户在此目录下都有一个单独的子目录
/lib		基本系统库文件，32位
/lib64		基本系统库文件，64位
/media		挂载文件系统的临时挂载点，/media多用于自动挂载的设备，如(USB 鼠标键盘)
/mnt		挂载文件系统的临时挂载点，/mnt多用于管理员手动挂载，如(硬盘)
/opt		存放可选的应用程序包，一般用于第三方软件的安装
/proc		虚拟文件系统，存放系统内核和进程信息
/root		超级用户(root)的主目录。与普通用户的主目录相对应
/run		存放系统启动后临时生成的文件，如进程 ID 文件 (/run/*.pid)
/sbin		系统管理命令的可执行文件，需要(root)用户才能执行
/srv		存放系统运行后临时生成的文件
/sys		类似于 /proc，也是一个虚拟文件系统，通常用于查看和调整系统硬件配置
/tmp		临时文件目录。系统和应用程序会将临时文件存放在这里

/usr		包含用户级应用程序和文件，通常用于存放大多数用户安装的软件
            子目录有:
            /usr/bin: 包含普通用户可执行文件
            /usr/sbin: 包含超级用户可执行文件
            /usr/lib: 包含应用程序的库文件
            /usr/share: 存放共享的数据文件，如文档和配置示例
	
/var		存放经常变化的数据文件,如日志(/var/log)邮件(/var/mail)缓存(/var/cache) 
```



##### VI和VIM编辑器

```
安装vim：yum -y install vim
语法：vim 文件路径
```

![image-20240301201545762](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240301201545762.png)

1，命令模式

按`i`进入输入模式，按`:`进入底线命令模式

![image-20240301202722209](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240301202722209.png)

![image-20240301203657551](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240301203657551.png)

2，输入模式

对输入内容进行编辑，按`esc`进入命令模式

3，底线命令模式

在命令模式按`:`进入底线命令模式

![image-20240301205641516](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240301205641516.png)



#### 1,常见命令

##### 帮助类命令

1，`help`获取`shell`内置命令的帮助信息

```
help 命令
```

2，`man`查看命令的帮助信息(推荐)

```
man 命令
```

##### 开关机命令

1，将内存中的数据同步到硬盘中

```
sync
```

2，关闭系统，等同于`shutdown -h now`

```
poweroff
```

3，重启系统，等同于`shutdown -r now`

```
reboot
```

4，`shutdown`[选项] 时间

```
shutdown -h now  关机
shutdown -r now  重启
```

| 参数 | 功能                         |
| ---- | ---------------------------- |
| now  | 立刻关机                     |
| 时间 | 等待多久之后关机，单位为分钟 |

##### 服务管理类命令(重要)

临时对软件，对系统的启停服务命令

```shell
开启服务 		 systemctl start 服务名
关闭服务 		 systemctl stop 服务名
重启服务 		 systemctl restart 服务名
查看服务		 systemctl status 服务名
查看正在运行服务   systemctl -type service 服务名
```

永久开关命令

```shell
打开自启			systemctl enable 服务名
关闭自启			systemctl disable 服务名
查看服务是否自启	  systemctl is-enabled 服务名
查看所有服务自启配置	 systemctl list-unit-files
```

范例：

```shell
# 查看防火墙服务
systemctl status firewalld.service
```

```shell
# 查看网络管理器服务
systemctl status NetworkManager
```

#####  文件目录类命令(重要)

1，显示当前工作目录的绝对路径

```
pwd
```



2，显示当前目录下文件夹

```
ls
ls -a 显示隐藏文件
ls -l 以列表形式显示
ls -h 需要与-a,-l组合使用,表示以易于阅读形式，列出文件大小
```

![image-20240902090004253](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902090004253.png)



3，切换目录

```
cd [参数]
```

| 参数        | 说明                       |
| ----------- | -------------------------- |
| cd 绝对路径 | 切换路径                   |
| cd 相对路径 | 切换路径                   |
| cd          | 切换到home目录             |
| cd /        | 切换到根目录               |
| cd ..       | 切换到当前目录的上一级目录 |



4，创建文件夹和创建目录文件

```
mkdir [选项] 创建的目录
```

![image-20240902101656735](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902101656735.png)

```
-p 创建多层目录
mkdir 创建的目录 -p
```

![image-20240902101819300](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902101819300.png)

```
创建多个同级目录
mkdir {目录1,目录2, ...} -p
```

![image-20240902102033849](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902102033849.png)



5，专门用于删除空文件夹

```
rmdir 空文件夹
```



6，`touch`创建空文件

`linux`创建的文件不受文件后缀影响，文件后缀多给管理人员查看

```
touch 文件名称
```



7，`cp`复制文件或目录

```
cp [选项] day data  (功能描述: 复制day目录到data)
```

| 选项 | 功能               |
| ---- | ------------------ |
| -r   | 递归复制整个文件夹 |

复制文件至某个文件夹

![image-20240902104018979](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902104018979.png)

复制整个目录至某个文件夹

或者 `cp day/* data/ -r`

![image-20240902104442642](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902104442642.png)



7，`rm`删除文件

 [选项] 待删除的文件

```
rm -rf 待删除的文件
```

| 选项 | 功能                         |
| ---- | ---------------------------- |
| -r   | 递归删除目录所有内容         |
| -f   | 强制删除，不提示用户进行确认 |
| -v   | 显示指令的详细执行过程       |



8，`mv`移动文件与目录或重命名

```
语法：mv  参数1(被移到)  参数2(移动去的地方)
​	参数1，linux路径，表示被移动的文件或文件夹
​	参数2，linux路径，表示要移动去的地方，如果目标不在，则进行改名，确保目标存在(mv 可以用于创建新的文件或文件夹)
```

在根目录下创建`test`，移动至`/data`目录下改名为`rongchi`

![image-20240902114205733](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902114205733.png)

文件改名：把根目录下的`day`改成`test_day`

![image-20240902114411038](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902114411038.png)



9，查看文件

```shell
#cat [选项] 要查看的文件
cat [选项] 要查看的文件 查看文件内容，从第一行开始显示
```

| 选项 | 功能                       |
| ---- | -------------------------- |
| -n   | 显示所有行的行号，包括空行 |

```shell
#more 要查看的文件
#使用more打开文件后，若不想查看，立即按q，对于大文件来说，其运行速度比cat快
more 要查看的文件
```

```shell
#less 要查看的文件
less根据显示需要加载内容，对于显示大型文件具有高效率
```

1，`head`显示文件头部内容

```shell
head用于显示文件的开头部分内容，默认情况下head指令显示文件的前10行内容

head 文件 		(功能描述：查看文件头10行内容)
head -n 5 文件	(功能描述：查看文件头5行内容)
```

| 选项      | 功能                   |
| --------- | ---------------------- |
| -n <行数> | 指定显示头部内容的行数 |

2，`tail`输出文件尾部内容

`-f`显示文件最新追加的内容，监视文件变化

```shell
tail用于输出文件中尾部的内容，默认情况下tail指令显示文件的后10行内容

tail 文件			(功能描述：查看文件尾10行内容)
tail -n 5 文件	(功能描述：查看文件尾5行内容)
tail -f 文件		(功能描述：实时追踪文档的所有更新)
```



10，`echo`打印输出信息

```
echo [选项] [输出内容]
```

| 选项 | 功能                     |
| ---- | ------------------------ |
| -e   | 支持反斜线控制的字符转换 |
| \n   | 换行符                   |
| \t   | 制表符                   |
| \\\  | 输出 \ 本身              |

![image-20240902150331412](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902150331412.png)

`\n`和`\t`的使用

![image-20240902150947258](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902150947258.png)



**覆盖(重定向)`>` 和追加`>>`的使用**

```shell
ll > 文件			(功能描述：列表的内容写入文件a.txt中（覆盖a文件原本内容）)
ll >> 文件		(功能描述：列表的内容写入文件a.txt中（追加在a文件原本内容后面）)
cat 文件1 > 文件2	   (功能描述：将当前查看文件1的内容覆盖在文件2)
echo "内容" >> 文件	   (功能描述：将打印的内容追加在文件内)
```

![image-20240902153004633](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902153004633.png)

把`home`目录下显示的文件信息追加写入到根目录下的`/data/`目录下的`a.txt`文件中

![image-20240902153254309](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902153254309.png)

把`_.txt`显示的文件信息覆盖写入到根目录下的`/data/`目录下的`a.txt`文件中

`head`默认显示前10行

![image-20240902153748407](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902153748407.png)

把`echo`打印内容追加写入到根目录下的`/data/`目录下的`a.txt`文件中

![image-20240902154539269](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902154539269.png)



11，`ln`创建连接和软连接

连接表示目标资源的另外访问方式，表示一种路径。

软连接也称为符号连接，类似于`windows`里面的快捷方式，有自己的数据块，主要存放了连接其他文件的路径

```shell
ln [-s] [原文件或目录] [连接名]		(功能描述：给原文件创建一个链接)
```

| 选项 | 功能               |
| ---- | ------------------ |
| -s   | 创建的链接为软连接 |

将`/data/a.txt`文件软链接到根目录下，名称为`test`

![image-20240902170657154](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902170657154.png)

![image-20240902171159539](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902171159539.png)



12，`history`查看历史命令

```
history		(功能描述：查看已经执行过的历史命令)
```

把`history`查看的历史命令导入到文件中，再查找自己需要命令是工作中一种常见的解决方案

![image-20240902172404096](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240902172404096.png)



13，查看和修改主机名

1，查看主机名

```
hostname
```

2，修改主机名

```
vim /etc/hostname
```



##### 时间日期类命令

1，`date`显示当前时间

```shell
date						(功能描述：显示当前时间)
date "+%Y-%m-%d %H:%M:%S"	(功能描述：显示年月日时分秒)
```

![image-20240903094021831](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903094021831.png)

标准格式：`date +%F`

![image-20240903094312248](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903094312248.png)

2，`cal`查看日历

```
cal [选项]		(功能描述：不加选项，显示本月日历)
```

![image-20240903094908797](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903094908797.png)



##### 用户管理命令

1，`useradd`添加新用户

```
useradd 用户名			(功能描述：添加新用户)
useradd -g 组名 用户名  (功能描述：添加新用户到某个组)

useradd [-g -d] 用户名
​	选项： -g 指定用户的组，不指定 -g。会创建同名组并自动加入，指定 -g 需要组已经存在，如已存在同名组，必须使用 -g
​	选项：-d 指定用户home路径，不指定，home目录默认在：/home/用户名
```

`userdel -r`删除用户以及用户的home目录

```
userdel [-r] 用户名
​	选项：-r，删除用户的home目录，不使用 -r，删除用户时，home目录保留
```



1.1，`usermod`将某个用户加入至某个组

```shell
usermod [-aG] 用户组 用户名，将指定用户加入指定用户组

 useradd test04					创建了test04用户，并默认添加进入test04用户组
 usermod -aG itcast test04		把test04用户移动至itcast用户组中
```



2，`passwd`设置用户密码

```
passwd 用户名		(功能描述：设置用户密码)
```

![image-20240903095735735](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903095735735.png)

此时，`CentOS`系统交互界面会出现另一个账号

![image-20240903095913490](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903095913490.png)



3，`id`查看用户是否存在

```
id 用户名
```

![image-20240903100045167](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903100045167.png)

4，查看创建的所有用户

```shell
# 查看方式很多，进入用户文件里，甚至可以删除用户
vim /etc/passwd
```

以`tcpdump`为标记，`tcpdump`之前都是系统用户

![image-20240903103931517](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903103931517.png)

5，`su - (switch user)`切换用户

```
su 用户名称		(功能描述：切换用户，只能获得用户的执行权限，不能获得环境变量)
su - 用户名称	(功能描述：切换到用户并获得该用户的环境变量及执行权限)
```

![image-20240903100830937](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903100830937.png)

6，`who`查看登录用户信息

```
whoami		(功能描述：显示自身用户名称)
who am i	(功能描述：显示登陆用户的用户名)
```

![image-20240903101406440](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903101406440.png)



7，`sudo`设置普通用户具有`root`权限

使用`sudo`命令，为普通的命令授权，临时以`root`身份执行

- 在其它命令之前，带上`sudo`，即可为这一条命令临时赋予` root `授权

- 但并不是所有用户，都有权力使用`sudo`，需要为普通用户配置 `sudo` 认证

```
sudo 命令
```

![image-20240903102319387](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903102319387.png)



##### 组管理类命令

1，`groupadd`新增组

```
groupadd 组名
```

2，`groupdel`删除组

```
groupdel 组名
```

3，查看创建了那些组

```shell
# 查看方式很多，进入用户文件里，甚至可以删除用户
vim /etc/group
```

以`tcpdump`为标记，`tcpdump`之前都是系统组，`tcpdump`之后是自己的组

![image-20240903103713484](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903103713484.png)

4，`usermod`修改用户

```
usermod -g 用户组 用户名
```

| 选项 | 功能                                   |
| ---- | -------------------------------------- |
| -g   | 修改用户的初始登陆组，给定的组必须存在 |



##### 文件权限类命令(重要)

1，文件属性信息解读

![image-20240903104745865](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903104745865.png)

权限细节总共分为10个槽位

​	`-` 表示文件	`d` 表示文件夹	`l` 表示软连接

![image-20240307172729307](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240307172729307.png)

举例：drwxr-xr-x 表示：

* 这是一个文件夹，首字母d表示
* 所属用户权限是：有r有w有x，rwx
* 所属用户组权限是：有r无w有x，r-x  ( - 表示无此权限)
* 其他用户权限是：有r无w有x，r-x 

**rwx**

* r 可读权限
* w 可写权限
* x 可执行权限

针对文件，文件夹不同，rwx的含义有细微差别

* r，针对文件可以查看文件内容(文件夹，可以查看文件夹内容，如ls命令)
* w，针对文件可以修改此文件(文件夹，可以创建，删除，改名)
* x，针对文件可以将文件作为程序执行(文件夹，表示可以更改工作目录到此文件夹，即cd进入)



2，权限信息解读

![image-20240903105041296](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903105041296.png)

* 序号1，表示文件，文件夹的权限控制信息
* 序号2，表示文件，文件夹所属用户
* 序号3，表示文件，文件夹所属用户组



3，`chmod`改变文件权限

使用`chmod`命令，修改文件，文件夹的权限信息(只有文件，文件夹的所属用户或`root`用户可以修改)

```shell
语法： chmod  [-R]  文件或文件夹

​ 选项：-R ，对文件夹内的全部内容应用同样的操作
u :user用户权限
g :group用户组权限
o :other其他用户权限
```

将`a.txt`文件权限修改为: `rwx r-x --x`

```shell
chmod u=rwx,g=rx,o=x a.txt
```

![image-20240903111046765](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903111046765.png)

| 选项 | 功能                                                         |
| ---- | ------------------------------------------------------------ |
| -R   | chmod 带-R 修改的不只是文件夹权限，还有里面所有的文件或文件夹权限 |

将`/data`目录及目录下所有文件的权限修改为: `rwx r-x --x`

![image-20240903111426620](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903111426620.png)

**权限变更方式(推荐)**

![image-20240408191620845](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240408191620845.png)

```
 r=4 w=2 x=1
​ rwx=4+2+1=7

​	r代表4，w代表2，x代表1
​	rwx的互相组合可以得到从0到7的8种权限组合

解释二进制表示：
0 123 456 789
  000 000 000
二进制
  100 010 001
十进制
    4   2   1
```

赋予`/data`目录及其目录下的所有文件最大权限

![image-20240903112533871](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903112533871.png)

最合理的权限

```shell
chmod -R 755 data/
```



4，`chown`改变所有者

使用chown命令，可以修改文件，文件夹的所属用户和用户组(此命令只适用于root用户执行)

![image-20240903153432669](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903153432669.png)

```
chowm [选项] [用户] [文件或目录] 	(功能描述：改变文件或者目录的所有者)

chown命令

​	功能，修改文件，文件夹的所属用户，组
​	限制，只可root执行
​	语法：chown  [-R]  [用户]  [:] [用户组]  文件或文件夹
​	选项，-R，同chmod，对文件夹全部内容应用相同规则
​	选项，用户，修改所属用户
​	选项，用户组，修改所属用户组
​	:  用于分隔用户和用户组
```

###### 实战练习

```
1.在opt目录下创建java目录，用于安装java框架。所有者为java部门的领导张总，所属组为java部门，张总有全部的权限，部门其他开发有读和执行的权限，其他人只有读的权限。
2.在opt目录下创建bigdata目录，用户大数据框架的安装。所有者为大数据部门的王总，所属组为bigdata部门,王总有全部的权限，部门其他人有读写执行权限，其他人没有权限。
3.使用root用户在opt目录下创建mysq1文件夹，用于安装mysq1，赋予其他用户读的权限。
4.使用root用户在opt目录下创建redis文件夹，用于安装使用redis，赋予其他用户读和执行的权限
```

解决方案：

1，进入`/opt`目录创建题目要求的4个文件夹，都是同级文件夹

```
mkdir /opt/{java,bigdata,mysq1,redis} -p
```

2，创建用户`zhang`，创建用户组`java`，安装`java`

注意：创键用户同时，会默认创建同名的所属用户组(可保留可删除)

```
# 创建用户
useradd zhang
# 创建用户组
groupadd java
# 进入/java目录安装
yum install java -y
```

2.1，给`zhang`用户root权限

**注意：这里给某个用户`root`权限需要进入`/etc/sudoers`**，`sudoers`文件如果无法修改，可以使用`chmod`改权限

```
vim /etc/sudoers

zhang    ALL=(ALL)      NOPASSWD:ALL
```

![image-20240903155951187](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903155951187.png)

2.2，切换到`zhang`用户，配置`java`目录权限和所属用户和组

```
# 权限配置
sudo chmod -R 754 java/
# 所属用户和组
sudo chown -R zhang:java java/
```

2.3，将用户加入到对应的组

![image-20240903163111221](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903163111221.png)

3，234要求同理

![image-20240903154820544](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903154820544.png)

`vim /etc/passwd`

![image-20240903155043571](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903155043571.png)

`vim /etc/group`

![image-20240903155206159](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903155206159.png)



##### 搜索查找类命令(重要)

1，`find`查找文件或者目录

```
find指令将从指定目录向下递归地遍历其各个子目录，将满足条件的文件显示在终端
find [搜索范围] [选项]

find -name "start*"
```

| 选项            | 功能                             |
| --------------- | -------------------------------- |
| -name<查询方式> | 按照指定的文件名查找模式查找文件 |
| -user<用户名>   | 查找属于指定用户名的所有文件     |
| -size<文件大小> | 按照指定的文件大小查找文件       |



2，`grep`过滤查找及`|`管道符

`|`管道符，表示`管道符前面命令的处理结果`是`管道符后面命令的输入`

`grep`选项 查找内容 源文件

| 选项 | 功能           |
| ---- | -------------- |
| -n   | 显示匹配及行号 |

范例：

找出所有端口号中，带80端口的

```shell
# ps -ef 查看所有端口
# ps是任务管理器
ps -ef | grep 80

# 加上 -n 显示过滤内容行号
ps -ef | grep -n 80
```

![image-20240903171746225](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903171746225.png)



##### 压缩和解压缩命令

1，`gzip/gunzip`压缩

```shell
gzip 文件 		(功能描述：压缩文件，只能将文件压缩为*.gz文件)
gunzip 文件.gz	(功能描述：解压缩文件命令)

只能压缩文件，不能压缩目录
不保留原来的文件
```

![image-20240903172758162](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240903172758162.png)



2，`zip/unzip`压缩

```
zip [选项] XXX.zip 将要压缩的内容   (功能描述：压缩文件和目录命令)
unzip [选项] XXX.zip				(功能描述：解压缩文件命令)

windows和linux下 zip压缩格式是通用的
可以压缩目录并且保留源文件
```

| zip       | 功能                       |
| --------- | -------------------------- |
| -r        | 压缩目录                   |
| **unzip** | **功能**                   |
| -d <目录> | 指定解压缩后文件的存放目录 |

解压缩`unzip 文件.zip`:会展示全部解压内容

![image-20250418112018983](./Linux图/image-20250418112018983.png)

压缩`zip -r 文件.zip 目录下文件/`:展示全部压缩内容 压缩进度会显示百分比

![image-20250418112135568](./Linux图/image-20250418112135568.png)



3，`tar`打包

```
tar [选项] XXX.tar.gz 将要打包进去的内容 	(功能描述：打包目录，压缩后的文件格式.tar.gz)
```

| 选项 | 功能               |
| ---- | ------------------ |
| -z   | 打包同时压缩       |
| -c   | 产生 .tar 打包文件 |
| -v   | 显示详细信息       |
| -f   | 指定压缩后的文件名 |
| -x   | 解包 .tar文件      |

压缩 `-zcvf`

![image-20240904093809087](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904093809087.png)

解压 `-zxvf`

![image-20240904093840067](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904093840067.png)



##### 磁盘分区类命令

1，`df(disk free 空余硬盘)`查看磁盘空间使用情况

```
df 选项 		(功能描述：列出文件系统的整体磁盘使用量，检查文件系统磁盘空间占用情况)
```

| 选项 | 说明                                    |
| ---- | --------------------------------------- |
| -h   | 以GBytes，MBytes，KBytes 等格式自行显示 |

`df -h`查看磁盘使用情况

![image-20240904095418003](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904095418003.png)



2，`fdisk`查看分区

```
fdisk -l	(功能描述：查看磁盘分区详情)
```

![image-20240904095656020](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904095656020.png)



##### 进程线程类命令(重要)

进程是正在执行的一个程序或命令，每一个进程都是一个运行的实体，并占用一定的系统资源

1，`ps(process status 进程状态)`查看当前系统进程状态

```
ps -aux | grep XXX		(功能描述：查看系统中所有进程)
ps -ef | grep XXX		(功能描述：可以查看子父进程之间的关系)
```

| 选项 | 功能                   |
| ---- | ---------------------- |
| -a   | 选择所有进程           |
| -u   | 显示所有用户的所有进程 |
| -x   | 显示没有终端的进程     |

`ps -aux`显示信息说明

```
USER:该进程是由哪个用户产生的
PID:进程的ID号
%CPU:该进程占用CPU资源的百分比，占用越高，进程越耗费资源
%MEM:该进程占用物理内存的百分比，占用越高，进程越耗费资源
VSZ:该进程占用虚拟内存的大小，单位KB
RSS:该进程占用实际物理内存的大小，单位KB
TTY:该进程是在哪个终端中运行的。其中tty1-tty7代表本地控制台终端，tty1-tty6是本地的字符界面终端，tty7是图形终端。pts/0-255代表虚拟终端
STAT:进程状态。常见的状态有:R:运行、5:睡眠、T:停止状态、5:包含子进程、+:位于后台
START:该进程的启动时间
TIME:该进程占用CPU的运算时间，注意不是系统时间
COMMAND:产生此进程的命令名
```

`ps -ef`显示信息说明

```
UID:用户ID
PID:进程ID
PPID:父进程ID
C:CPU用于计算执行优先级的因子。数值越大，表明进程是CPU密集型运算，执行优先级会降低;数值越小，表明进程是I/0密集型运算，执行优先级会提高
STIME:进程启动的时间
TTY:完整的终端名称
TIME:CPU时间
CMD:启动进程所用的命令和参数
```



2，`kill`终止进程

```
kill [选项] 进程号	(功能描述：通过进程号杀死进程)
killall 进程名称	 (功能描述：通过进程名称杀死进程，也支持通配符)
```

| 选项 | 功能                 |
| ---- | -------------------- |
| -9   | 表示强迫进程立即停止 |



##### 系统定时任务命令

[Linux中Crontab（定时任务）命令详解及使用教程_linux定时任务命令-CSDN博客](https://blog.csdn.net/qq_51514930/article/details/124269555)

[ChatGPT定时任务](https://chatgpt.com/c/67724458-551c-8009-9f46-33500ea077ee)

1，`crond`服务管理

安装定时任务

```shell
yum install vixie-cron 
yum install crontabs
注：vixie-cron软件包是cron的主程序；
crontabs软件包是用来安装、卸装、或列举用来驱动 cron 守护进程的表格的程序。
cron是linux的内置服务，但它不自动起来，可以用以下的方法启动、关闭这个服务：
/sbin/service crond start #启动服务
/sbin/service crond stop #关闭服务
/sbin/service crond restart #重启服务
/sbin/service crond reload #重新载入配置
```

重新启动`crond`服务

```
systemctl restart crond
```

2，`crontab`定时任务设置

```
crontab [选项]
```

| 选项 | 功能                           |
| ---- | ------------------------------ |
| -e   | 编辑 crontab定时任务           |
| -l   | 查询 crontab任务               |
| -f   | 删除当前用户所有的 crontab任务 |

https://www.bilibili.com/video/BV19W4y1w7cM/?p=51&spm_id_from=pageDriver&vd_source=da0ca5a74459b110b3a6da903d245e14



##### `rpm`软件包

```
RPM(RedHat Package Manager)，RedHat软件包管理工具，类似windows里面的setup.exed.是Linux这系列操作系统里面的打包安装工具，它虽然是RedHat的标志，但理念是通用的。
```

1，`rpm`查询命令

```
rpm -qa 		(功能描述：查询所安装的所有rpm软件包)
rpm -ql 服务名	  (功能描述：查看安装位置)

由于软件包较多，一般会采用过滤：rpm -qa | grep rpm 软件包
```

![image-20240904111026779](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904111026779.png)



2，`rpm`卸载命令

```
rpm -e 软件包
rpm -e --nodeps 软件包
```

| 选项     | 功能                   |
| -------- | ---------------------- |
| -e       | 卸载软件包             |
| --nodeps | 卸载软件时，不检查依赖 |

##### `yum`软件管理工具

1，`yum`安装程序命令

```
yum [选项] [参数]
```

![image-20240408210836152](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240408210836152.png)

| 参数         | 功能                          |
| ------------ | ----------------------------- |
| install      | 安装rpm软件包                 |
| update       | 更新rpm软件包                 |
| check-update | 检查是否有可用的更新rpm软件包 |
| remove       | 删除指定的rpm软件包           |
| list         | 显示软件包信息                |
| clean        | 清理yum过期的缓存             |
| deplist      | 显示yum软件包的所有依赖关系   |

![image-20240904112956971](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904112956971.png)



##### 1,rz/sz上传和下载

https://blog.csdn.net/zhouyingxiong/article/details/120367127

`rz指令`和`sz指令`是一对上传与下载的指令。它们的软件包名为`lrzsz`

```shell
# 安装lrzsz软件包
yum install -y lrzsz

# 上传 rz -y是覆盖上传
上传命令格式：rz 回车后会弹出windows窗口，然后选择文件。默认下载到当前目录

# 下载 sz -y 文件名 则是覆盖下载
下载命令格式：sz 文件名
```



##### 2,scp高级用法

https://blog.csdn.net/leisure_life/article/details/80042423

环境 ：在没有`winSCP`等传输工具的情况下，同网段两台主机(10.230.82.85和10.230.82.88)，通过scp把一台主机的文件传入另一台。

10.230.82.85 源主机，有需要文件的主机

10.230.82.88 目标主机，待传入文件的主机

![image-20250306154503781](./Linux图/image-20250306154503781.png)

```shell
# 在目标主机(也就是要传入文件的主机)输入 scp 源主机用户名@源主机IP:/源主机文件路径/源主机文件 目标主机文件名

[topteact@jzhbomc-db-panwei-600g ~]$ scp topteact@10.230.82.85:/home/topteact/chaosblade_new.tar.gz chaosblade_new.tar.gz
You have logged onto a secured server..All accesses logged
topteact@10.230.82.85's password: 
chaosblade_new.tar.gz                                                                                                 100%   76MB 279.2MB/s   00:00    
```

![image-20250306155123265](./Linux图/image-20250306155123265.png)



#### 特别：Linux高级用法

1，`ps -aux`查看所有进程

```
ps -aux | grep nginx  查看nginx进程
```

![image-20240929162849298](./../Nginx/Nginx%E5%9B%BE/image-20240929162849298.png)

2，`top`查看内存占用率

3，`free`或`free -h`查看内存及使用情况

4，在使用`tar`打包时，如果想排除多个文件或者目录

```shell
格式：  tar --exclude="要排除的文件" [options] [archive_name] [path]

1，过滤单个文件夹（文件）
tar -zcvf aaa/bbb/aabb.tar.gz --exclude=aaa/ccc aaa
2.过滤多个文件夹（文件）
tar -zcvf aaa/bbb/aabb.tar.gz --exclude=aaa/ccc --exclude=aaa/ddd --exclude=aaa/eee.txt aaa
```

5，`scp`实现本地机器文件和远程机器文件的互传

```shell
scp /path/to/local/file user@remote_host:/path/to/remote/directory
	参数解析
		/path/to/local/file			本地机器上的文件路径
		user@remote_host			远程机器的用户名和主机地址（例如，username@192.168.1.100）
		/path/to/remote/directory 	 远程机器上的目标文件夹路径
		
如果需要上传整个目录，可以使用 -r 选项进行递归复制
scp -r /path/to/local/directory user@remote_host:/path/to/remote/directory

# 代码详解   https://chatgpt.com/c/67627ddb-9798-8009-8eba-1b140393f687
```

参考文献：

https://blog.csdn.net/shangguanliubei/article/details/140635170?spm=1001.2101.3001.6650.1&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7EYuanLiJiHua%7ECtr-1-140635170-blog-86530072.235%5Ev43%5Epc_blog_bottom_relevance_base5&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7EYuanLiJiHua%7ECtr-1-140635170-blog-86530072.235%5Ev43%5Epc_blog_bottom_relevance_base5&utm_relevant_index=2



#### 2,Shell编程语言

查看`linux`提供的shell解释器：`cat /etc/shells`

1，需求：创建一个`Shell`脚本，输出`helloworld`

```
touch helloworld.sh
或
vim helloworld.sh

在helloworld.sh中输入如下内容
# !/bin/bash
echo "helloworld"

执行脚本
sh helloworld.sh
bash helloworld.sh

# . 和 source 会继承脚本里面的变量
. helloworld.sh
source helloworld.sh
```



2，我希望一个`sh`脚本是可以直接运行的，不需要每次在输入`bash`或`sh`

采用输入脚本的绝对路径或相对路径执行执行脚本(必须具有可执行权限`+x`)

```
首先要赋予helloworld.sh脚本的 +x 权限
```

![image-20240904154320570](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904154320570.png)

相对路径执行和绝对路径执行

![image-20240904154448500](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240904154448500.png)



`sh`，`bash` 和`. ` `source`的区别

`sh`和`bash`是在当前`shell`中打开一个临时的子`shell`来执行脚本内容，当脚本内容结束，则子`shell`关闭，回到父`shell`中

`. ` 和 `source`执行时，无需打开子`shell`，直接在当前`shell`执行脚本内容。这也是为什么每次修改完`/etc/profile`文件后，需要`cource`一下的原因



##### 变量

###### 系统预定义变量

```shell
常用的系统变量
$HOME	$PWD	$SHELL	$USER
```

1，显示当前`Shell`中所有变量：`set`

2，查看系统变量的值：`echo $HOME`



###### 自定义变量

**基本语法**

- 定义变量：变量名=变量值，注意`=`号前后不能有空格

- 撤销变量：`unset`变量名

- 声明静态变量：`readonly`变量，注意：不能`unset`


**变量定义规则**

- 变量名称可以由字母，数字和下划线组成，但不能以数字开头，环境变量建议大写

- 等号两侧不能由空格(在`linux`里面空格表示隔断)

- 在`bash`中，变量默认类型都是字符串类型，无法直接进行数值运算

- 变量的值如果有空格，需要使用双引号或单引号括起来

![image-20240905143007856](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905143007856.png)

![image-20240905143132044](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905143132044.png)

被撤销的变量,再次输出会什么都没有

![image-20240905143321441](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905143321441.png)

声明了静态变量后，既不能更改也不能撤销

![image-20240905143554086](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905143554086.png)

在`bash`中，变量默认类型都是字符串类型，无法直接进行数值运算

![image-20240905143929705](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905143929705.png)

输出的值如果带空格，需要引号扩起来

![image-20240905144415557](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905144415557.png)

可以把变量提升为全局环境变量，可供其他`Shell`程序使用(使用前先通过`export 变量`导出)

`export 变量`相当于继承，默认是不继承的

![image-20240905145530804](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905145530804.png)



###### 特殊变量

1，**$n**	(功能描述:n为数字，$0代表该脚本名称，$1-$9代表第一到第九个参数，十以上的参数，十以上的参数需要用大括号包含，如${10})

```
vim parameter.sh
```

在`parameter.sh`写入

![image-20240905154834406](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905154834406.png)

执行`parameter.sh`

![image-20240905154900816](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905154900816.png)

**$0**代表该脚本名称

```
vim parameter.sh
	
    echo '----$n----' 

    echo $0         # $0，自动打印脚本名称等信息 
    echo $1    
    echo $2 
    echo $3  
```

![image-20240905155543130](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905155543130.png)



2，**$#**  获取用户输出参数的个数

![image-20240905160106173](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905160106173.png)



3，**$***  这个变量代表命令行中所有的参数，$* 把所有的参数看成一个整体

4，**$@** 这个变量也代表命令行中所有的参数,，不过 $@ 把每个参数区分对待

注意：加上双引号会表示成一个整体

```shell
echo '----$n----'
echo $0         # $0，自动打印脚本名称等信息 
echo $1
echo $2    
echo $3 
              
echo '----$#----' 
echo $#

echo '----$*----'
echo $*

echo '----$@----' 
echo $@ 
```

![image-20240905161510633](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905161510633.png)



5，**$？**最后一次执行的命令的返回状态，如果这个变量的值为0，证明上一个命令正确执行；如果这个变量的值为非0，则证明上一个命令执行不正确。

![image-20240905162056573](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240905162056573.png)



###### 运算符

```
"$((运算式))" 或 "$[运算式]"
```

计算`(2+3)*4`的值

![image-20240906095927022](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906095927022.png)

在一个运算里面调用另一个运算

![image-20240906100150433](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906100150433.png)



###### 条件判断

```
test condition
[ condition ] (注意condition前后要有空格)
注意：条件非空即为True，[ atguigu ]返回true，[]返回false
```

1，两个整数之间比较判断

```
两个整数之间比较
-eq 等于(equal)				-ne 不等于(not equal)
-lt 小于(less than)			-le 小于等于(less equal)
-gt 大于(greater than)		-ge 大于等于(greater equal)
```

注意：在1shell`中 0是True，1是False(不会报错)

可以用`echo $?`来判断

![image-20240906152405933](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906152405933.png)

2，按照文件权限进行判断

```
-r有读的权限(read)
-w有写的权限(write)
-x有执行的权限(execute)
```

![image-20240906152953419](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906152953419.png)

3，按照文件类型进行判断

```
-e文件存在(existence)
-f文件存在并且是一个常规的文件(file)
-d 文件存在并且是一个目录(directory)
```

![image-20240906153317910](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906153317910.png)



##### 流程控制

###### if判断

注意：

​	[ 条件判断式 ]，中括号和条件判断式之间必须有空格

​	`if`后要有空格

![image-20240906154051054](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906154051054.png)

![image-20240906154335592](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240906154335592.png)

范例：

`if`条件判断式

```shell
vim if.sh

#!/bin/bash
  
if [[ $1 -gt 100 ]]; then
        #statements
        echo "第一个参数大于100"
elif [[ $1 -gt 50 ]]; then
        #statements
        echo "第一个参数小于等于100大于50"
else
        echo "第一个参数小于等于50"
fi

```

```shell
# 赋予可执行权限
chmod +x if.sh
```

![image-20240909091538382](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909091538382.png)



###### case语句

![image-20240909092337291](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909092337291.png)

注意：

- case行尾必须为单词`in`，每一个模式匹配必须以右括号`")`
- 双分号`;;`表示命令序列结束，相当于java中的`break`
- 最后的`*)`表示默认模式，相当于java中的`default`

范例：

```shell
vim case.sh

#!/bin/bash
  
case $1 in
        "start")
        echo "启动程序"
                ;;
        "stop")
        echo ”关闭程序“
                ;;
        "status")
        echo "查看程序状态"
                ;;
        *)
        echo "错误的参数"
                ;;
esac
```

![image-20240909094021107](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909094021107.png)



###### for循环

**用法一**

![image-20240909094632891](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909094632891.png)

范例：

求1加至100的和

```shell
vim sum.sh

#!/bin/bash
  
sum=0
for (( i=1;i<101;++i )); do
        sum=$[$sum+$i]
done

echo $sum

```

![image-20240909095304039](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909095304039.png)

有时候需要外部输入一个参数 `$1`

```shell
vim sum.sh

#!/bin/bash
  
sum=0
for (( i=1;i<=$1;++i )); do
        sum=$[$sum+$i]
done

echo $sum
```

![image-20240909095713999](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909095713999.png)



**用法二(推荐)**

**![image-20240909095844230](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909095844230.png)**

范例：循环开启对应软件服务

```shell
vim jiqun.sh

#!/bin/bash

for i in jiqun100 jiqun101 jiqun102; do
        echo "开启$i的软件服务"
done   
```

![image-20240909100318052](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909100318052.png)



案例：

**$* $@ 和 "$*"  "$@"的区别**

`$* $@`不会被看作一个整体

```shell
#!/bin/bash
  
echo '------$*------'
for i in $*; do
        echo "开启$i的软件服务"
done

echo '------$@------'
for i in $@; do
        echo "开启$i的软件服务"
done
```

![image-20240909101620820](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909101620820.png)



注意：加上双引号会表示成一个整体

 "$*"会被看作一个整体

` "$@"`不会被看作一个整体

```shell
#!/bin/bash
  
echo '------$*------'
for i in "$*"; do
        echo "开启$i的软件服务"
done

echo '------$@------'
for i in "$@"; do
        echo "开启$i的软件服务"
done
```

![image-20240909101856536](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909101856536.png)



###### while循环

![image-20240909104552888](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909104552888.png)

范例：使用while循环从1加到100

```shell
vim while_sum.sh

#!/bin/bash
  
i=1
sum=0
while [[ $i -le 100 ]]; do
        sum=$[$sum + $i]
        i=$[$i+1]
done
echo $sum
```

![image-20240909110159669](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909110159669.png)



##### read读取控制台输入

```shell
read (选项) [参数]
```

选项：										参数：

`-p`指定读取值时的提示符						变量：指定读取值的变量名

`-t`指定读取值时等待的时间(秒)

```shell
#vim read.sh

#!/bin/bash

# -t在7秒内，-p后接提示符("请输入您的姓名:") [变量]
read -t 7 -p "请输入您的姓名:" NAME
echo "您好 $NAME"
```

![image-20240909111020265](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909111020265.png)



##### 函数

###### 系统函数

1，`basename`

```shell 
basename [string/pathname][suffix] (功能描述：basename命令会删掉所有的前缀,保留最后一个`/文件`)
```

选项：

[suffix]为后缀，如果`suffix`被指定了，`basename`会将`pathname`或`string`中的`suffix`去掉

![image-20240909113234933](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909113234933.png)



2，`dirname`

```
dirname 文件绝对路径 (功能描述：从给定的包含绝对路径的文件名中去除文件名(非目录的部分)，然后返回剩下的路径(目录的部分))
```

![image-20240909113654286](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909113654286.png)



###### 自定义函数

![image-20240909113854333](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909113854333.png)

- 必须在调用函数的地方之前，声明函数。`shell`脚本是逐行运行。不会像其它语言一样先编译
- 函数返回值，只能通过`$?`系统变量获得。可以显示如：`return`返回，如果不加，将以最后一条命令运行结果最为返回值。`return`后跟数值n(0-255)

范例：函数方式实现2个数求和

```shell
 vim func.sh
 
 #!/bin/bash
function func(){
        sum=0
        sum=$[$1+$2]
        echo "$sum"

}

read -t 30 -p "请输入x的值" x
read -t 30 -p "请输入y的值" y

echo "x+y的结果是:"
func $x $y
```

![image-20240909144242052](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240909144242052.png)



##### 工具

###### cut

cut的工作就是“剪”，在文件中负责剪切数据用，cut命令从文件的每一行剪切字节，字符和字段并将这些字节，字符和字段输出

```
cut [选项参数] filename
说明：默认分隔符是制表符
```

| 选项参数 | 功能                                           |
| -------- | ---------------------------------------------- |
| -f       | 列号，提取第几行                               |
| -d       | 分隔符，按照指定分隔符分割列，默认是制表符"\t" |
| -c       | 指定具体的字符                                 |

![image-20240910100114905](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910100114905.png)

指定具体的某个字符

![image-20240910100308549](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910100308549.png)

指定前面1~3个字符

![image-20240910100529888](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910100529888.png)



###### awk

一个强大的文本分析工具，把文件逐行的读入，以空格为默认分隔符将每行切片，切开的部分在进行分析处理

```
awk [选项参数] '/pattern1/{action1} /pattern2/{action2}...'filename

pattern:表示awk在数据中查找的内容，就是匹配模式
action:在找到匹配内容时所执行的一系列命令
```

| 选项参数 | 功能                 |
| -------- | -------------------- |
| -F       | 指定输入文件拆分隔符 |
| -v       | 赋值一个用户定义变量 |



###### sort

`sort`命令将文件进行排序，并将排序结果标准输出

```
sort (选项) (参数)
参数：指定待排序的文件列表
```

| 选项 | 说明                     |
| ---- | ------------------------ |
| -n   | 依照数值的大小排序       |
| -r   | 以相反的顺序来排序       |
| -t   | 设置排序时所用的分隔字符 |
| -k   | 指定需要排序的列         |

![image-20240910111311782](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910111311782.png)



###### wc

wc命令用来统计文件信息。利用wc指令可以计算文件的行数，字节数，字符数等

```
wc [选项参数] filename
```

| 选项参数 | 功能             |
| -------- | ---------------- |
| -l       | 统计文件行数     |
| -w       | 统计文件的单词数 |
| -m       | 统计文件的字符数 |
| -c       | 统计文件的字节数 |



#### 3，正则表达式

用于字符匹配

##### 常用字符

###### ^ 匹配一行的开头

```shell
# 匹配出现所有以a开头的行
cat /etc/passwd | grep ^a
```

![image-20240910112355272](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910112355272.png)



###### $ 匹配一行的结束

```shell
# 匹配出现所有以t开头的行
cat /etc/passwd | grep t$
```

![image-20240910112704889](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910112704889.png)

案例：

```shell
# ^ $ 的组合使用
# 匹配以a开头 t结尾的
cat /etc/passwd | grep ^at$
```



###### . 匹配一个任意的字符

```shell
# 匹配以r开头 t结尾的文件或文件夹
cat /etc/passwd | grep r..t
```

匹配`r..t`任意两个字符，前面是r，后面是t

![image-20240910113209381](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910113209381.png)

案例1：

```shell
# 常见搭配 .*
# 匹配以r开头 t结尾的
cat /etc/passwd | grep r.*t
```

![image-20240910113548535](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910113548535.png)

案例2：

```shell
# 匹配root开头 bash结尾的
cat /etc/passwd | grep ^root.*bash$
```

![image-20240910113846402](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910113846402.png)



###### [ ] 匹配某个范围内的一个字符

```shell
[6,8]			匹配6或者8
[0-9]			匹配一个0-9的数
[0-9]*			匹配任意长度的数字字符串
[a-z]			匹配一个a-z之间的字符
[a-z]*			匹配任意长度的字母字符串
[a-c,e-f]		匹配a-c或者e-f之间的任意字符
```

![image-20240910144109171](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910144109171.png)



###### \ 转义 匹配带有特殊含义的字符

转义字符并不会单独使用，由于一些特殊字符(^和$)都有待定的匹配模式，当我们想要匹配这些特殊字符本身时。

我们就需要用到转义字符，来匹配特殊字符本身。

![image-20240910145142731](C:\Users\27252\Desktop\桌面图标\常用夹\Linux\Linux图\image-20240910145142731.png)
